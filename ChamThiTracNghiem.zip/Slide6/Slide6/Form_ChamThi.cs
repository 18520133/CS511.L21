﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Slide6
{
    public partial class Form_ChamThi : Form
    {
        DataTable dt = new DataTable();
        public Form_ChamThi()
        {
            InitializeComponent();
            dt.Columns.Add("Question");
            dt.Columns.Add("Answer");
            
        }

        private void ChamThi_Load(object sender, EventArgs e)
        {
            
        }
        

        private void button_docFile_Click(object sender, EventArgs e)
        {
            textBox_deThi.Text = File.ReadAllText(textBox_duongDanFile.Text + textBox_tenFile.Text);
            dataGridView1.DataSource = dt;
            for (int i=1;i<=50;i++)
            {
                string stt = i.ToString();
                string qst = "Question " + stt;
                dt.Rows.Add(qst,"");
                
            }
        }

        private void button_luuFileDapAn_Click(object sender, EventArgs e)
        {
            string text = "";
            for (int i = 0; i < 50; i++)
            {
                text += dt.Rows[i]["Answer"].ToString()+"\n";
                
            }
            string path = @"C:\Users\Admin\Downloads\TraLoi.txt";
            File.WriteAllText(path, text);
            
            MessageBox.Show("Lưu thành công!");
        }

        private void button_xemDapAn_Click(object sender, EventArgs e)
        {
            dt.Columns.Add("Result");
            string tenfile = @"C:\Users\Admin\Downloads\DapAn_01.txt";
            StreamReader sr = new StreamReader(tenfile);
            string str;
            int i = 0;
            while ((str = sr.ReadLine()) != null&&i<49)
            {
                dt.Rows[i]["Result"]=str;
                i++;
            }
            sr.Close();
            int s = -1;
            for (int j=0;j<50;j++)
            {
                if (dt.Rows[j]["Answer"].ToString() == dt.Rows[j]["Result"].ToString())
                    s++;
            }
            textBox_soCauDung.Text= s.ToString();
            textBox_soCauSai.Text =(50- s).ToString();
        }
    }
}
