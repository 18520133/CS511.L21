﻿
namespace Slide6
{
    partial class Form_ChamThi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_nhapDe = new System.Windows.Forms.GroupBox();
            this.button_docFile = new System.Windows.Forms.Button();
            this.textBox_tenFile = new System.Windows.Forms.TextBox();
            this.textBox_duongDanFile = new System.Windows.Forms.TextBox();
            this.label_tenFile = new System.Windows.Forms.Label();
            this.label_duongDanFile = new System.Windows.Forms.Label();
            this.groupBox_ketQua = new System.Windows.Forms.GroupBox();
            this.button_luuFileDapAn = new System.Windows.Forms.Button();
            this.textBox_KQ_tenFile = new System.Windows.Forms.TextBox();
            this.textBox_KQ_duongDanFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_xemDapAn = new System.Windows.Forms.Button();
            this.textBox_soCauSai = new System.Windows.Forms.TextBox();
            this.textBox_soCauDung = new System.Windows.Forms.TextBox();
            this.label_soCauSai = new System.Windows.Forms.Label();
            this.label_soCauDung = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox_deThi = new System.Windows.Forms.TextBox();
            this.groupBox_nhapDe.SuspendLayout();
            this.groupBox_ketQua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_nhapDe
            // 
            this.groupBox_nhapDe.BackColor = System.Drawing.Color.LightGreen;
            this.groupBox_nhapDe.Controls.Add(this.button_docFile);
            this.groupBox_nhapDe.Controls.Add(this.textBox_tenFile);
            this.groupBox_nhapDe.Controls.Add(this.textBox_duongDanFile);
            this.groupBox_nhapDe.Controls.Add(this.label_tenFile);
            this.groupBox_nhapDe.Controls.Add(this.label_duongDanFile);
            this.groupBox_nhapDe.Location = new System.Drawing.Point(7, 16);
            this.groupBox_nhapDe.Name = "groupBox_nhapDe";
            this.groupBox_nhapDe.Size = new System.Drawing.Size(316, 125);
            this.groupBox_nhapDe.TabIndex = 0;
            this.groupBox_nhapDe.TabStop = false;
            this.groupBox_nhapDe.Text = "NHẬP ĐỀ";
            // 
            // button_docFile
            // 
            this.button_docFile.Location = new System.Drawing.Point(93, 88);
            this.button_docFile.Name = "button_docFile";
            this.button_docFile.Size = new System.Drawing.Size(114, 31);
            this.button_docFile.TabIndex = 4;
            this.button_docFile.Text = "Đọc file";
            this.button_docFile.UseVisualStyleBackColor = true;
            this.button_docFile.Click += new System.EventHandler(this.button_docFile_Click);
            // 
            // textBox_tenFile
            // 
            this.textBox_tenFile.Location = new System.Drawing.Point(78, 55);
            this.textBox_tenFile.Name = "textBox_tenFile";
            this.textBox_tenFile.Size = new System.Drawing.Size(215, 31);
            this.textBox_tenFile.TabIndex = 3;
            this.textBox_tenFile.Text = "TracNghiem_01.txt";
            // 
            // textBox_duongDanFile
            // 
            this.textBox_duongDanFile.Location = new System.Drawing.Point(144, 18);
            this.textBox_duongDanFile.Name = "textBox_duongDanFile";
            this.textBox_duongDanFile.Size = new System.Drawing.Size(150, 31);
            this.textBox_duongDanFile.TabIndex = 2;
            this.textBox_duongDanFile.Text = "C:\\Users\\Admin\\Downloads\\";
            // 
            // label_tenFile
            // 
            this.label_tenFile.AutoSize = true;
            this.label_tenFile.Location = new System.Drawing.Point(7, 51);
            this.label_tenFile.Name = "label_tenFile";
            this.label_tenFile.Size = new System.Drawing.Size(66, 25);
            this.label_tenFile.TabIndex = 1;
            this.label_tenFile.Text = "Tên file";
            // 
            // label_duongDanFile
            // 
            this.label_duongDanFile.AutoSize = true;
            this.label_duongDanFile.Location = new System.Drawing.Point(5, 21);
            this.label_duongDanFile.Name = "label_duongDanFile";
            this.label_duongDanFile.Size = new System.Drawing.Size(131, 25);
            this.label_duongDanFile.TabIndex = 0;
            this.label_duongDanFile.Text = "Đường dẫn file";
            // 
            // groupBox_ketQua
            // 
            this.groupBox_ketQua.BackColor = System.Drawing.Color.LightGreen;
            this.groupBox_ketQua.Controls.Add(this.button_luuFileDapAn);
            this.groupBox_ketQua.Controls.Add(this.textBox_KQ_tenFile);
            this.groupBox_ketQua.Controls.Add(this.textBox_KQ_duongDanFile);
            this.groupBox_ketQua.Controls.Add(this.label2);
            this.groupBox_ketQua.Controls.Add(this.label1);
            this.groupBox_ketQua.Controls.Add(this.button_xemDapAn);
            this.groupBox_ketQua.Controls.Add(this.textBox_soCauSai);
            this.groupBox_ketQua.Controls.Add(this.textBox_soCauDung);
            this.groupBox_ketQua.Controls.Add(this.label_soCauSai);
            this.groupBox_ketQua.Controls.Add(this.label_soCauDung);
            this.groupBox_ketQua.Location = new System.Drawing.Point(6, 149);
            this.groupBox_ketQua.Name = "groupBox_ketQua";
            this.groupBox_ketQua.Size = new System.Drawing.Size(317, 208);
            this.groupBox_ketQua.TabIndex = 4;
            this.groupBox_ketQua.TabStop = false;
            this.groupBox_ketQua.Text = "KẾT QUẢ";
            // 
            // button_luuFileDapAn
            // 
            this.button_luuFileDapAn.Location = new System.Drawing.Point(8, 171);
            this.button_luuFileDapAn.Name = "button_luuFileDapAn";
            this.button_luuFileDapAn.Size = new System.Drawing.Size(149, 31);
            this.button_luuFileDapAn.TabIndex = 8;
            this.button_luuFileDapAn.Text = "Lưu file đáp án";
            this.button_luuFileDapAn.UseVisualStyleBackColor = true;
            this.button_luuFileDapAn.Click += new System.EventHandler(this.button_luuFileDapAn_Click);
            // 
            // textBox_KQ_tenFile
            // 
            this.textBox_KQ_tenFile.Location = new System.Drawing.Point(129, 136);
            this.textBox_KQ_tenFile.Name = "textBox_KQ_tenFile";
            this.textBox_KQ_tenFile.Size = new System.Drawing.Size(166, 31);
            this.textBox_KQ_tenFile.TabIndex = 7;
            this.textBox_KQ_tenFile.Text = "TraLoi.txt";
            // 
            // textBox_KQ_duongDanFile
            // 
            this.textBox_KQ_duongDanFile.Location = new System.Drawing.Point(138, 100);
            this.textBox_KQ_duongDanFile.Name = "textBox_KQ_duongDanFile";
            this.textBox_KQ_duongDanFile.Size = new System.Drawing.Size(157, 31);
            this.textBox_KQ_duongDanFile.TabIndex = 6;
            this.textBox_KQ_duongDanFile.Text = "C:\\Users\\Admin\\Downloads\\";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tên file";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Đường dẫn file";
            // 
            // button_xemDapAn
            // 
            this.button_xemDapAn.Location = new System.Drawing.Point(178, 171);
            this.button_xemDapAn.Name = "button_xemDapAn";
            this.button_xemDapAn.Size = new System.Drawing.Size(129, 31);
            this.button_xemDapAn.TabIndex = 5;
            this.button_xemDapAn.Text = "Xem đáp án";
            this.button_xemDapAn.UseVisualStyleBackColor = true;
            this.button_xemDapAn.Click += new System.EventHandler(this.button_xemDapAn_Click);
            // 
            // textBox_soCauSai
            // 
            this.textBox_soCauSai.Location = new System.Drawing.Point(129, 64);
            this.textBox_soCauSai.Name = "textBox_soCauSai";
            this.textBox_soCauSai.Size = new System.Drawing.Size(166, 31);
            this.textBox_soCauSai.TabIndex = 5;
            // 
            // textBox_soCauDung
            // 
            this.textBox_soCauDung.Location = new System.Drawing.Point(131, 27);
            this.textBox_soCauDung.Name = "textBox_soCauDung";
            this.textBox_soCauDung.Size = new System.Drawing.Size(164, 31);
            this.textBox_soCauDung.TabIndex = 4;
            // 
            // label_soCauSai
            // 
            this.label_soCauSai.AutoSize = true;
            this.label_soCauSai.Location = new System.Drawing.Point(7, 64);
            this.label_soCauSai.Name = "label_soCauSai";
            this.label_soCauSai.Size = new System.Drawing.Size(91, 25);
            this.label_soCauSai.TabIndex = 1;
            this.label_soCauSai.Text = "Số câu sai";
            // 
            // label_soCauDung
            // 
            this.label_soCauDung.AutoSize = true;
            this.label_soCauDung.Location = new System.Drawing.Point(5, 27);
            this.label_soCauDung.Name = "label_soCauDung";
            this.label_soCauDung.Size = new System.Drawing.Size(112, 25);
            this.label_soCauDung.TabIndex = 0;
            this.label_soCauDung.Text = "Số câu đúng";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 366);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(311, 72);
            this.dataGridView1.TabIndex = 5;
            // 
            // textBox_deThi
            // 
            this.textBox_deThi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_deThi.Location = new System.Drawing.Point(329, 14);
            this.textBox_deThi.Multiline = true;
            this.textBox_deThi.Name = "textBox_deThi";
            this.textBox_deThi.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox_deThi.Size = new System.Drawing.Size(468, 424);
            this.textBox_deThi.TabIndex = 6;
            // 
            // Form_ChamThi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox_deThi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox_ketQua);
            this.Controls.Add(this.groupBox_nhapDe);
            this.Name = "Form_ChamThi";
            this.Text = "Chấm thi trắc nghiệm";
            this.Load += new System.EventHandler(this.ChamThi_Load);
            this.groupBox_nhapDe.ResumeLayout(false);
            this.groupBox_nhapDe.PerformLayout();
            this.groupBox_ketQua.ResumeLayout(false);
            this.groupBox_ketQua.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_nhapDe;
        private System.Windows.Forms.Button button_docFile;
        private System.Windows.Forms.TextBox textBox_tenFile;
        private System.Windows.Forms.TextBox textBox_duongDanFile;
        private System.Windows.Forms.Label label_tenFile;
        private System.Windows.Forms.Label label_duongDanFile;
        private System.Windows.Forms.GroupBox groupBox_ketQua;
        private System.Windows.Forms.Button button_luuFileDapAn;
        private System.Windows.Forms.TextBox textBox_KQ_tenFile;
        private System.Windows.Forms.TextBox textBox_KQ_duongDanFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_xemDapAn;
        private System.Windows.Forms.TextBox textBox_soCauSai;
        private System.Windows.Forms.TextBox textBox_soCauDung;
        private System.Windows.Forms.Label label_soCauSai;
        private System.Windows.Forms.Label label_soCauDung;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox_deThi;
    }
}

