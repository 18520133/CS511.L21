﻿
namespace BaiTH1
{
    partial class BookTickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookTickets));
            this.groupBox_datve = new System.Windows.Forms.GroupBox();
            this.button_huyve = new System.Windows.Forms.Button();
            this.label_soghe = new System.Windows.Forms.Label();
            this.textBox_soghe = new System.Windows.Forms.TextBox();
            this.comboBox_rap = new System.Windows.Forms.ComboBox();
            this.label_rap = new System.Windows.Forms.Label();
            this.button_datve = new System.Windows.Forms.Button();
            this.comboBox_suat = new System.Windows.Forms.ComboBox();
            this.comboBox_phim = new System.Windows.Forms.ComboBox();
            this.label_suat = new System.Windows.Forms.Label();
            this.label_datve_phim = new System.Windows.Forms.Label();
            this.label_datve_ngay = new System.Windows.Forms.Label();
            this.dateTimePicker_datve = new System.Windows.Forms.DateTimePicker();
            this.groupBox_suatchieu = new System.Windows.Forms.GroupBox();
            this.comboBox_suatChieu = new System.Windows.Forms.ComboBox();
            this.comboBox_suatChieu_rap = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_huy_suatchieu = new System.Windows.Forms.Button();
            this.button_them_suatChieu = new System.Windows.Forms.Button();
            this.comboBox_suatChieu_phim = new System.Windows.Forms.ComboBox();
            this.label_thoigian = new System.Windows.Forms.Label();
            this.label_suat_phim = new System.Windows.Forms.Label();
            this.dateTimePicker_danhMuc_suat = new System.Windows.Forms.DateTimePicker();
            this.label_suat_ngay = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker_soDo_thoiGian = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.button_xemGhe = new System.Windows.Forms.Button();
            this.comboBox_soDo_rap = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_soDo_suat = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_seatsMap = new System.Windows.Forms.Panel();
            this.label_35 = new System.Windows.Forms.Label();
            this.label_31 = new System.Windows.Forms.Label();
            this.label_37 = new System.Windows.Forms.Label();
            this.label_36 = new System.Windows.Forms.Label();
            this.label_34 = new System.Windows.Forms.Label();
            this.label_33 = new System.Windows.Forms.Label();
            this.label_32 = new System.Windows.Forms.Label();
            this.label_30 = new System.Windows.Forms.Label();
            this.label_29 = new System.Windows.Forms.Label();
            this.label_22 = new System.Windows.Forms.Label();
            this.label_23 = new System.Windows.Forms.Label();
            this.label_24 = new System.Windows.Forms.Label();
            this.label_25 = new System.Windows.Forms.Label();
            this.label_26 = new System.Windows.Forms.Label();
            this.label_27 = new System.Windows.Forms.Label();
            this.label_28 = new System.Windows.Forms.Label();
            this.label_21 = new System.Windows.Forms.Label();
            this.label_20 = new System.Windows.Forms.Label();
            this.label_19 = new System.Windows.Forms.Label();
            this.label_18 = new System.Windows.Forms.Label();
            this.label_17 = new System.Windows.Forms.Label();
            this.label_16 = new System.Windows.Forms.Label();
            this.label_15 = new System.Windows.Forms.Label();
            this.label_8 = new System.Windows.Forms.Label();
            this.label_9 = new System.Windows.Forms.Label();
            this.label_10 = new System.Windows.Forms.Label();
            this.label_11 = new System.Windows.Forms.Label();
            this.label_12 = new System.Windows.Forms.Label();
            this.label_13 = new System.Windows.Forms.Label();
            this.label_14 = new System.Windows.Forms.Label();
            this.label_7 = new System.Windows.Forms.Label();
            this.label_6 = new System.Windows.Forms.Label();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_4 = new System.Windows.Forms.Label();
            this.label_3 = new System.Windows.Forms.Label();
            this.label_2 = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.panel_manHinh = new System.Windows.Forms.Panel();
            this.pictureBox_panel1_avatarFilm = new System.Windows.Forms.PictureBox();
            this.label_panel_namePhim = new System.Windows.Forms.Label();
            this.label_manHinh = new System.Windows.Forms.Label();
            this.button_14 = new System.Windows.Forms.Button();
            this.button_15 = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_29 = new System.Windows.Forms.Button();
            this.button_28 = new System.Windows.Forms.Button();
            this.button_27 = new System.Windows.Forms.Button();
            this.button_30 = new System.Windows.Forms.Button();
            this.button_16 = new System.Windows.Forms.Button();
            this.button_13 = new System.Windows.Forms.Button();
            this.button_32 = new System.Windows.Forms.Button();
            this.button_26 = new System.Windows.Forms.Button();
            this.button_31 = new System.Windows.Forms.Button();
            this.button_12 = new System.Windows.Forms.Button();
            this.button_17 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_11 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_25 = new System.Windows.Forms.Button();
            this.button_33 = new System.Windows.Forms.Button();
            this.button_18 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_19 = new System.Windows.Forms.Button();
            this.button_24 = new System.Windows.Forms.Button();
            this.button_35 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_34 = new System.Windows.Forms.Button();
            this.button_9 = new System.Windows.Forms.Button();
            this.button_20 = new System.Windows.Forms.Button();
            this.button_23 = new System.Windows.Forms.Button();
            this.button_36 = new System.Windows.Forms.Button();
            this.button_37 = new System.Windows.Forms.Button();
            this.button_22 = new System.Windows.Forms.Button();
            this.button_21 = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.button_10 = new System.Windows.Forms.Button();
            this.panel_2_addInforFilm = new System.Windows.Forms.Panel();
            this.comboBox_thongTin_trangThai = new System.Windows.Forms.ComboBox();
            this.button_thongTin_xoaPhim = new System.Windows.Forms.Button();
            this.button_thongTin_themVao = new System.Windows.Forms.Button();
            this.pictureBox_thongTin_anh = new System.Windows.Forms.PictureBox();
            this.textBox_thongTin_thongTin = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label_trangthai = new System.Windows.Forms.Label();
            this.textBox_thongTin_tacGia = new System.Windows.Forms.TextBox();
            this.label_tacgia = new System.Windows.Forms.Label();
            this.textBox_thongTin_phim = new System.Windows.Forms.TextBox();
            this.label_tenphim = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_themPhim_themPhim = new System.Windows.Forms.Button();
            this.label_dadat = new System.Windows.Forms.Label();
            this.textBox_soGheDaDat = new System.Windows.Forms.TextBox();
            this.label_controng = new System.Windows.Forms.Label();
            this.textBox_soGheChuaDat = new System.Windows.Forms.TextBox();
            this.groupBox_datve.SuspendLayout();
            this.groupBox_suatchieu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_seatsMap.SuspendLayout();
            this.panel_manHinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_panel1_avatarFilm)).BeginInit();
            this.panel_2_addInforFilm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_thongTin_anh)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_datve
            // 
            this.groupBox_datve.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox_datve.Controls.Add(this.textBox_soGheChuaDat);
            this.groupBox_datve.Controls.Add(this.label_controng);
            this.groupBox_datve.Controls.Add(this.textBox_soGheDaDat);
            this.groupBox_datve.Controls.Add(this.label_dadat);
            this.groupBox_datve.Controls.Add(this.button_huyve);
            this.groupBox_datve.Controls.Add(this.label_soghe);
            this.groupBox_datve.Controls.Add(this.textBox_soghe);
            this.groupBox_datve.Controls.Add(this.comboBox_rap);
            this.groupBox_datve.Controls.Add(this.label_rap);
            this.groupBox_datve.Controls.Add(this.button_datve);
            this.groupBox_datve.Controls.Add(this.comboBox_suat);
            this.groupBox_datve.Controls.Add(this.comboBox_phim);
            this.groupBox_datve.Controls.Add(this.label_suat);
            this.groupBox_datve.Controls.Add(this.label_datve_phim);
            this.groupBox_datve.Controls.Add(this.label_datve_ngay);
            this.groupBox_datve.Controls.Add(this.dateTimePicker_datve);
            this.groupBox_datve.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_datve.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox_datve.Location = new System.Drawing.Point(8, 161);
            this.groupBox_datve.Name = "groupBox_datve";
            this.groupBox_datve.Size = new System.Drawing.Size(198, 178);
            this.groupBox_datve.TabIndex = 0;
            this.groupBox_datve.TabStop = false;
            this.groupBox_datve.Text = "Đặt vé xem phim";
            this.groupBox_datve.Enter += new System.EventHandler(this.groupBox_datve_Enter);
            // 
            // button_huyve
            // 
            this.button_huyve.BackColor = System.Drawing.Color.DarkCyan;
            this.button_huyve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_huyve.ForeColor = System.Drawing.Color.White;
            this.button_huyve.Location = new System.Drawing.Point(140, 94);
            this.button_huyve.Name = "button_huyve";
            this.button_huyve.Size = new System.Drawing.Size(35, 28);
            this.button_huyve.TabIndex = 12;
            this.button_huyve.Text = "-";
            this.button_huyve.UseVisualStyleBackColor = false;
            this.button_huyve.Click += new System.EventHandler(this.button_huyve_Click);
            // 
            // label_soghe
            // 
            this.label_soghe.AutoSize = true;
            this.label_soghe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_soghe.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_soghe.Location = new System.Drawing.Point(5, 130);
            this.label_soghe.Name = "label_soghe";
            this.label_soghe.Size = new System.Drawing.Size(46, 15);
            this.label_soghe.TabIndex = 11;
            this.label_soghe.Text = "Số ghế";
            // 
            // textBox_soghe
            // 
            this.textBox_soghe.Enabled = false;
            this.textBox_soghe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_soghe.Location = new System.Drawing.Point(51, 128);
            this.textBox_soghe.Name = "textBox_soghe";
            this.textBox_soghe.ReadOnly = true;
            this.textBox_soghe.Size = new System.Drawing.Size(123, 21);
            this.textBox_soghe.TabIndex = 10;
            // 
            // comboBox_rap
            // 
            this.comboBox_rap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_rap.FormattingEnabled = true;
            this.comboBox_rap.Location = new System.Drawing.Point(51, 99);
            this.comboBox_rap.Name = "comboBox_rap";
            this.comboBox_rap.Size = new System.Drawing.Size(36, 23);
            this.comboBox_rap.TabIndex = 8;
            this.comboBox_rap.SelectedIndexChanged += new System.EventHandler(this.comboBox_rap_SelectedIndexChanged);
            this.comboBox_rap.Click += new System.EventHandler(this.comboBox_rap_Click);
            // 
            // label_rap
            // 
            this.label_rap.AutoSize = true;
            this.label_rap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_rap.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_rap.Location = new System.Drawing.Point(8, 102);
            this.label_rap.Name = "label_rap";
            this.label_rap.Size = new System.Drawing.Size(30, 15);
            this.label_rap.TabIndex = 7;
            this.label_rap.Text = "Rạp";
            // 
            // button_datve
            // 
            this.button_datve.BackColor = System.Drawing.Color.DarkCyan;
            this.button_datve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_datve.ForeColor = System.Drawing.Color.Transparent;
            this.button_datve.Location = new System.Drawing.Point(99, 94);
            this.button_datve.Name = "button_datve";
            this.button_datve.Size = new System.Drawing.Size(35, 28);
            this.button_datve.TabIndex = 6;
            this.button_datve.Text = "+";
            this.button_datve.UseVisualStyleBackColor = false;
            this.button_datve.Click += new System.EventHandler(this.button_datve_Click);
            // 
            // comboBox_suat
            // 
            this.comboBox_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_suat.FormattingEnabled = true;
            this.comboBox_suat.Location = new System.Drawing.Point(51, 71);
            this.comboBox_suat.Name = "comboBox_suat";
            this.comboBox_suat.Size = new System.Drawing.Size(124, 23);
            this.comboBox_suat.TabIndex = 5;
            this.comboBox_suat.SelectedIndexChanged += new System.EventHandler(this.comboBox_suat_SelectedIndexChanged);
            this.comboBox_suat.Click += new System.EventHandler(this.comboBox_suat_Click);
            // 
            // comboBox_phim
            // 
            this.comboBox_phim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_phim.FormattingEnabled = true;
            this.comboBox_phim.Location = new System.Drawing.Point(51, 47);
            this.comboBox_phim.Name = "comboBox_phim";
            this.comboBox_phim.Size = new System.Drawing.Size(124, 23);
            this.comboBox_phim.TabIndex = 4;
            this.comboBox_phim.SelectedIndexChanged += new System.EventHandler(this.comboBox_phim_SelectedIndexChanged);
            this.comboBox_phim.Click += new System.EventHandler(this.comboBox_phim_Click);
            // 
            // label_suat
            // 
            this.label_suat.AutoSize = true;
            this.label_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_suat.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_suat.Location = new System.Drawing.Point(7, 73);
            this.label_suat.Name = "label_suat";
            this.label_suat.Size = new System.Drawing.Size(32, 15);
            this.label_suat.TabIndex = 3;
            this.label_suat.Text = "Suất";
            // 
            // label_datve_phim
            // 
            this.label_datve_phim.AutoSize = true;
            this.label_datve_phim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_datve_phim.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_datve_phim.Location = new System.Drawing.Point(6, 47);
            this.label_datve_phim.Name = "label_datve_phim";
            this.label_datve_phim.Size = new System.Drawing.Size(36, 15);
            this.label_datve_phim.TabIndex = 2;
            this.label_datve_phim.Text = "Phim";
            // 
            // label_datve_ngay
            // 
            this.label_datve_ngay.AutoSize = true;
            this.label_datve_ngay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_datve_ngay.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_datve_ngay.Location = new System.Drawing.Point(7, 20);
            this.label_datve_ngay.Name = "label_datve_ngay";
            this.label_datve_ngay.Size = new System.Drawing.Size(35, 15);
            this.label_datve_ngay.TabIndex = 1;
            this.label_datve_ngay.Text = "Ngày";
            // 
            // dateTimePicker_datve
            // 
            this.dateTimePicker_datve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_datve.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_datve.Location = new System.Drawing.Point(51, 20);
            this.dateTimePicker_datve.Name = "dateTimePicker_datve";
            this.dateTimePicker_datve.Size = new System.Drawing.Size(124, 26);
            this.dateTimePicker_datve.TabIndex = 0;
            this.dateTimePicker_datve.Value = new System.DateTime(2021, 4, 8, 0, 0, 0, 0);
            // 
            // groupBox_suatchieu
            // 
            this.groupBox_suatchieu.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox_suatchieu.Controls.Add(this.comboBox_suatChieu);
            this.groupBox_suatchieu.Controls.Add(this.comboBox_suatChieu_rap);
            this.groupBox_suatchieu.Controls.Add(this.label3);
            this.groupBox_suatchieu.Controls.Add(this.button_huy_suatchieu);
            this.groupBox_suatchieu.Controls.Add(this.button_them_suatChieu);
            this.groupBox_suatchieu.Controls.Add(this.comboBox_suatChieu_phim);
            this.groupBox_suatchieu.Controls.Add(this.label_thoigian);
            this.groupBox_suatchieu.Controls.Add(this.label_suat_phim);
            this.groupBox_suatchieu.Controls.Add(this.dateTimePicker_danhMuc_suat);
            this.groupBox_suatchieu.Controls.Add(this.label_suat_ngay);
            this.groupBox_suatchieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_suatchieu.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox_suatchieu.Location = new System.Drawing.Point(8, 18);
            this.groupBox_suatchieu.Name = "groupBox_suatchieu";
            this.groupBox_suatchieu.Size = new System.Drawing.Size(197, 137);
            this.groupBox_suatchieu.TabIndex = 1;
            this.groupBox_suatchieu.TabStop = false;
            this.groupBox_suatchieu.Text = "Danh mục suất chiếu";
            this.groupBox_suatchieu.Enter += new System.EventHandler(this.groupBox_suatchieu_Enter);
            // 
            // comboBox_suatChieu
            // 
            this.comboBox_suatChieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_suatChieu.FormattingEnabled = true;
            this.comboBox_suatChieu.Items.AddRange(new object[] {
            "07:00",
            "09:00",
            "11:00",
            "13:00",
            "15:00",
            "17:00",
            ""});
            this.comboBox_suatChieu.Location = new System.Drawing.Point(58, 79);
            this.comboBox_suatChieu.Name = "comboBox_suatChieu";
            this.comboBox_suatChieu.Size = new System.Drawing.Size(116, 23);
            this.comboBox_suatChieu.TabIndex = 14;
            this.comboBox_suatChieu.Click += new System.EventHandler(this.comboBox_suatChieu_thoiGian_Click);
            // 
            // comboBox_suatChieu_rap
            // 
            this.comboBox_suatChieu_rap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_suatChieu_rap.FormattingEnabled = true;
            this.comboBox_suatChieu_rap.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.comboBox_suatChieu_rap.Location = new System.Drawing.Point(58, 109);
            this.comboBox_suatChieu_rap.Name = "comboBox_suatChieu_rap";
            this.comboBox_suatChieu_rap.Size = new System.Drawing.Size(36, 23);
            this.comboBox_suatChieu_rap.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label3.Location = new System.Drawing.Point(8, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Rạp";
            // 
            // button_huy_suatchieu
            // 
            this.button_huy_suatchieu.BackColor = System.Drawing.Color.DarkCyan;
            this.button_huy_suatchieu.ForeColor = System.Drawing.Color.White;
            this.button_huy_suatchieu.Location = new System.Drawing.Point(140, 105);
            this.button_huy_suatchieu.Name = "button_huy_suatchieu";
            this.button_huy_suatchieu.Size = new System.Drawing.Size(35, 28);
            this.button_huy_suatchieu.TabIndex = 11;
            this.button_huy_suatchieu.Text = "-";
            this.button_huy_suatchieu.UseVisualStyleBackColor = false;
            this.button_huy_suatchieu.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_them_suatChieu
            // 
            this.button_them_suatChieu.BackColor = System.Drawing.Color.DarkCyan;
            this.button_them_suatChieu.ForeColor = System.Drawing.Color.White;
            this.button_them_suatChieu.Location = new System.Drawing.Point(98, 105);
            this.button_them_suatChieu.Name = "button_them_suatChieu";
            this.button_them_suatChieu.Size = new System.Drawing.Size(35, 28);
            this.button_them_suatChieu.TabIndex = 10;
            this.button_them_suatChieu.Text = "+";
            this.button_them_suatChieu.UseVisualStyleBackColor = false;
            this.button_them_suatChieu.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox_suatChieu_phim
            // 
            this.comboBox_suatChieu_phim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_suatChieu_phim.FormattingEnabled = true;
            this.comboBox_suatChieu_phim.Location = new System.Drawing.Point(58, 51);
            this.comboBox_suatChieu_phim.Name = "comboBox_suatChieu_phim";
            this.comboBox_suatChieu_phim.Size = new System.Drawing.Size(116, 23);
            this.comboBox_suatChieu_phim.TabIndex = 10;
            this.comboBox_suatChieu_phim.SelectedIndexChanged += new System.EventHandler(this.comboBox_danhmuc_phim_SelectedIndexChanged);
            this.comboBox_suatChieu_phim.Click += new System.EventHandler(this.comboBox_danhmuc_phim_Click);
            // 
            // label_thoigian
            // 
            this.label_thoigian.AutoSize = true;
            this.label_thoigian.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_thoigian.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_thoigian.Location = new System.Drawing.Point(5, 84);
            this.label_thoigian.Name = "label_thoigian";
            this.label_thoigian.Size = new System.Drawing.Size(32, 15);
            this.label_thoigian.TabIndex = 9;
            this.label_thoigian.Text = "Suất";
            // 
            // label_suat_phim
            // 
            this.label_suat_phim.AutoSize = true;
            this.label_suat_phim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_suat_phim.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_suat_phim.Location = new System.Drawing.Point(5, 54);
            this.label_suat_phim.Name = "label_suat_phim";
            this.label_suat_phim.Size = new System.Drawing.Size(36, 15);
            this.label_suat_phim.TabIndex = 8;
            this.label_suat_phim.Text = "Phim";
            // 
            // dateTimePicker_danhMuc_suat
            // 
            this.dateTimePicker_danhMuc_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_danhMuc_suat.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_danhMuc_suat.Location = new System.Drawing.Point(59, 22);
            this.dateTimePicker_danhMuc_suat.Name = "dateTimePicker_danhMuc_suat";
            this.dateTimePicker_danhMuc_suat.Size = new System.Drawing.Size(117, 26);
            this.dateTimePicker_danhMuc_suat.TabIndex = 6;
            this.dateTimePicker_danhMuc_suat.ValueChanged += new System.EventHandler(this.dateTimePicker_danhMuc_suat_ValueChanged_1);
            this.dateTimePicker_danhMuc_suat.Enter += new System.EventHandler(this.dateTimePicker_danhMuc_suat_Enter);
            this.dateTimePicker_danhMuc_suat.Leave += new System.EventHandler(this.dateTimePicker_danhMuc_suat_Leave);
            this.dateTimePicker_danhMuc_suat.Move += new System.EventHandler(this.dateTimePicker_danhMuc_suat_Move);
            // 
            // label_suat_ngay
            // 
            this.label_suat_ngay.AutoSize = true;
            this.label_suat_ngay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_suat_ngay.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_suat_ngay.Location = new System.Drawing.Point(4, 26);
            this.label_suat_ngay.Name = "label_suat_ngay";
            this.label_suat_ngay.Size = new System.Drawing.Size(35, 15);
            this.label_suat_ngay.TabIndex = 6;
            this.label_suat_ngay.Text = "Ngày";
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.BackColor = System.Drawing.Color.LightCyan;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(211, 18);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(676, 538);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox1.Controls.Add(this.dateTimePicker_soDo_thoiGian);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.button_xemGhe);
            this.groupBox1.Controls.Add(this.comboBox_soDo_rap);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox_soDo_suat);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox1.Location = new System.Drawing.Point(8, 413);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 139);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sơ đồ rạp";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // dateTimePicker_soDo_thoiGian
            // 
            this.dateTimePicker_soDo_thoiGian.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_soDo_thoiGian.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_soDo_thoiGian.Location = new System.Drawing.Point(51, 28);
            this.dateTimePicker_soDo_thoiGian.Name = "dateTimePicker_soDo_thoiGian";
            this.dateTimePicker_soDo_thoiGian.Size = new System.Drawing.Size(126, 26);
            this.dateTimePicker_soDo_thoiGian.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label8.Location = new System.Drawing.Point(5, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Ngày";
            // 
            // button_xemGhe
            // 
            this.button_xemGhe.BackColor = System.Drawing.Color.DarkCyan;
            this.button_xemGhe.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_xemGhe.ForeColor = System.Drawing.Color.White;
            this.button_xemGhe.Location = new System.Drawing.Point(10, 110);
            this.button_xemGhe.Margin = new System.Windows.Forms.Padding(2);
            this.button_xemGhe.Name = "button_xemGhe";
            this.button_xemGhe.Size = new System.Drawing.Size(176, 28);
            this.button_xemGhe.TabIndex = 15;
            this.button_xemGhe.Text = "Xem sơ đồ rạp";
            this.button_xemGhe.UseVisualStyleBackColor = false;
            this.button_xemGhe.Click += new System.EventHandler(this.button_xemGhe_Click);
            // 
            // comboBox_soDo_rap
            // 
            this.comboBox_soDo_rap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_soDo_rap.FormattingEnabled = true;
            this.comboBox_soDo_rap.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.comboBox_soDo_rap.Location = new System.Drawing.Point(50, 84);
            this.comboBox_soDo_rap.Name = "comboBox_soDo_rap";
            this.comboBox_soDo_rap.Size = new System.Drawing.Size(36, 23);
            this.comboBox_soDo_rap.TabIndex = 14;
            this.comboBox_soDo_rap.SelectedIndexChanged += new System.EventHandler(this.comboBox_soDo_rap_SelectedIndexChanged);
            this.comboBox_soDo_rap.Click += new System.EventHandler(this.comboBox_soDo_rap_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(8, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "Rạp";
            // 
            // comboBox_soDo_suat
            // 
            this.comboBox_soDo_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_soDo_suat.FormattingEnabled = true;
            this.comboBox_soDo_suat.Items.AddRange(new object[] {
            "07:00",
            "09:00",
            "11:00",
            "13:00",
            "15:00"});
            this.comboBox_soDo_suat.Location = new System.Drawing.Point(50, 56);
            this.comboBox_soDo_suat.Name = "comboBox_soDo_suat";
            this.comboBox_soDo_suat.Size = new System.Drawing.Size(126, 23);
            this.comboBox_soDo_suat.TabIndex = 7;
            this.comboBox_soDo_suat.SelectedIndexChanged += new System.EventHandler(this.comboBox_soDo_suat_SelectedIndexChanged);
            this.comboBox_soDo_suat.Click += new System.EventHandler(this.comboBox_soDo_suat_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(6, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Suất";
            // 
            // panel_seatsMap
            // 
            this.panel_seatsMap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel_seatsMap.BackColor = System.Drawing.Color.LightCyan;
            this.panel_seatsMap.Controls.Add(this.label_35);
            this.panel_seatsMap.Controls.Add(this.label_31);
            this.panel_seatsMap.Controls.Add(this.label_37);
            this.panel_seatsMap.Controls.Add(this.label_36);
            this.panel_seatsMap.Controls.Add(this.label_34);
            this.panel_seatsMap.Controls.Add(this.label_33);
            this.panel_seatsMap.Controls.Add(this.label_32);
            this.panel_seatsMap.Controls.Add(this.label_30);
            this.panel_seatsMap.Controls.Add(this.label_29);
            this.panel_seatsMap.Controls.Add(this.label_22);
            this.panel_seatsMap.Controls.Add(this.label_23);
            this.panel_seatsMap.Controls.Add(this.label_24);
            this.panel_seatsMap.Controls.Add(this.label_25);
            this.panel_seatsMap.Controls.Add(this.label_26);
            this.panel_seatsMap.Controls.Add(this.label_27);
            this.panel_seatsMap.Controls.Add(this.label_28);
            this.panel_seatsMap.Controls.Add(this.label_21);
            this.panel_seatsMap.Controls.Add(this.label_20);
            this.panel_seatsMap.Controls.Add(this.label_19);
            this.panel_seatsMap.Controls.Add(this.label_18);
            this.panel_seatsMap.Controls.Add(this.label_17);
            this.panel_seatsMap.Controls.Add(this.label_16);
            this.panel_seatsMap.Controls.Add(this.label_15);
            this.panel_seatsMap.Controls.Add(this.label_8);
            this.panel_seatsMap.Controls.Add(this.label_9);
            this.panel_seatsMap.Controls.Add(this.label_10);
            this.panel_seatsMap.Controls.Add(this.label_11);
            this.panel_seatsMap.Controls.Add(this.label_12);
            this.panel_seatsMap.Controls.Add(this.label_13);
            this.panel_seatsMap.Controls.Add(this.label_14);
            this.panel_seatsMap.Controls.Add(this.label_7);
            this.panel_seatsMap.Controls.Add(this.label_6);
            this.panel_seatsMap.Controls.Add(this.label_5);
            this.panel_seatsMap.Controls.Add(this.label_4);
            this.panel_seatsMap.Controls.Add(this.label_3);
            this.panel_seatsMap.Controls.Add(this.label_2);
            this.panel_seatsMap.Controls.Add(this.label_1);
            this.panel_seatsMap.Controls.Add(this.panel_manHinh);
            this.panel_seatsMap.Controls.Add(this.button_14);
            this.panel_seatsMap.Controls.Add(this.button_15);
            this.panel_seatsMap.Controls.Add(this.button_1);
            this.panel_seatsMap.Controls.Add(this.button_2);
            this.panel_seatsMap.Controls.Add(this.button_29);
            this.panel_seatsMap.Controls.Add(this.button_28);
            this.panel_seatsMap.Controls.Add(this.button_27);
            this.panel_seatsMap.Controls.Add(this.button_30);
            this.panel_seatsMap.Controls.Add(this.button_16);
            this.panel_seatsMap.Controls.Add(this.button_13);
            this.panel_seatsMap.Controls.Add(this.button_32);
            this.panel_seatsMap.Controls.Add(this.button_26);
            this.panel_seatsMap.Controls.Add(this.button_31);
            this.panel_seatsMap.Controls.Add(this.button_12);
            this.panel_seatsMap.Controls.Add(this.button_17);
            this.panel_seatsMap.Controls.Add(this.button23);
            this.panel_seatsMap.Controls.Add(this.button_4);
            this.panel_seatsMap.Controls.Add(this.button_11);
            this.panel_seatsMap.Controls.Add(this.button_3);
            this.panel_seatsMap.Controls.Add(this.button_25);
            this.panel_seatsMap.Controls.Add(this.button_33);
            this.panel_seatsMap.Controls.Add(this.button_18);
            this.panel_seatsMap.Controls.Add(this.button_5);
            this.panel_seatsMap.Controls.Add(this.button_19);
            this.panel_seatsMap.Controls.Add(this.button_24);
            this.panel_seatsMap.Controls.Add(this.button_35);
            this.panel_seatsMap.Controls.Add(this.button_6);
            this.panel_seatsMap.Controls.Add(this.button_34);
            this.panel_seatsMap.Controls.Add(this.button_9);
            this.panel_seatsMap.Controls.Add(this.button_20);
            this.panel_seatsMap.Controls.Add(this.button_23);
            this.panel_seatsMap.Controls.Add(this.button_36);
            this.panel_seatsMap.Controls.Add(this.button_37);
            this.panel_seatsMap.Controls.Add(this.button_22);
            this.panel_seatsMap.Controls.Add(this.button_21);
            this.panel_seatsMap.Controls.Add(this.button_7);
            this.panel_seatsMap.Controls.Add(this.button_8);
            this.panel_seatsMap.Controls.Add(this.button_10);
            this.panel_seatsMap.Location = new System.Drawing.Point(209, 18);
            this.panel_seatsMap.Margin = new System.Windows.Forms.Padding(2);
            this.panel_seatsMap.Name = "panel_seatsMap";
            this.panel_seatsMap.Size = new System.Drawing.Size(676, 537);
            this.panel_seatsMap.TabIndex = 4;
            this.panel_seatsMap.Visible = false;
            this.panel_seatsMap.Click += new System.EventHandler(this.panel_seatsMap_Click);
            this.panel_seatsMap.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_seatsMap_Paint);
            // 
            // label_35
            // 
            this.label_35.AutoSize = true;
            this.label_35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_35.Location = new System.Drawing.Point(462, 85);
            this.label_35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_35.Name = "label_35";
            this.label_35.Size = new System.Drawing.Size(24, 17);
            this.label_35.TabIndex = 104;
            this.label_35.Text = "35";
            // 
            // label_31
            // 
            this.label_31.AutoSize = true;
            this.label_31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_31.Location = new System.Drawing.Point(202, 85);
            this.label_31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_31.Name = "label_31";
            this.label_31.Size = new System.Drawing.Size(24, 17);
            this.label_31.TabIndex = 103;
            this.label_31.Text = "31";
            // 
            // label_37
            // 
            this.label_37.AutoSize = true;
            this.label_37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_37.Location = new System.Drawing.Point(587, 85);
            this.label_37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_37.Name = "label_37";
            this.label_37.Size = new System.Drawing.Size(24, 17);
            this.label_37.TabIndex = 102;
            this.label_37.Text = "37";
            // 
            // label_36
            // 
            this.label_36.AutoSize = true;
            this.label_36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_36.Location = new System.Drawing.Point(523, 85);
            this.label_36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_36.Name = "label_36";
            this.label_36.Size = new System.Drawing.Size(24, 17);
            this.label_36.TabIndex = 101;
            this.label_36.Text = "36";
            // 
            // label_34
            // 
            this.label_34.AutoSize = true;
            this.label_34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_34.Location = new System.Drawing.Point(394, 85);
            this.label_34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_34.Name = "label_34";
            this.label_34.Size = new System.Drawing.Size(24, 17);
            this.label_34.TabIndex = 100;
            this.label_34.Text = "34";
            // 
            // label_33
            // 
            this.label_33.AutoSize = true;
            this.label_33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_33.Location = new System.Drawing.Point(331, 85);
            this.label_33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_33.Name = "label_33";
            this.label_33.Size = new System.Drawing.Size(24, 17);
            this.label_33.TabIndex = 99;
            this.label_33.Text = "33";
            // 
            // label_32
            // 
            this.label_32.AutoSize = true;
            this.label_32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_32.Location = new System.Drawing.Point(266, 85);
            this.label_32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_32.Name = "label_32";
            this.label_32.Size = new System.Drawing.Size(24, 17);
            this.label_32.TabIndex = 98;
            this.label_32.Text = "32";
            // 
            // label_30
            // 
            this.label_30.AutoSize = true;
            this.label_30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_30.Location = new System.Drawing.Point(136, 85);
            this.label_30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_30.Name = "label_30";
            this.label_30.Size = new System.Drawing.Size(24, 17);
            this.label_30.TabIndex = 97;
            this.label_30.Text = "30";
            // 
            // label_29
            // 
            this.label_29.AutoSize = true;
            this.label_29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_29.Location = new System.Drawing.Point(72, 85);
            this.label_29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_29.Name = "label_29";
            this.label_29.Size = new System.Drawing.Size(24, 17);
            this.label_29.TabIndex = 96;
            this.label_29.Text = "29";
            // 
            // label_22
            // 
            this.label_22.AutoSize = true;
            this.label_22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_22.Location = new System.Drawing.Point(586, 172);
            this.label_22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_22.Name = "label_22";
            this.label_22.Size = new System.Drawing.Size(24, 17);
            this.label_22.TabIndex = 95;
            this.label_22.Text = "22";
            // 
            // label_23
            // 
            this.label_23.AutoSize = true;
            this.label_23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_23.Location = new System.Drawing.Point(522, 172);
            this.label_23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_23.Name = "label_23";
            this.label_23.Size = new System.Drawing.Size(24, 17);
            this.label_23.TabIndex = 94;
            this.label_23.Text = "23";
            // 
            // label_24
            // 
            this.label_24.AutoSize = true;
            this.label_24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_24.Location = new System.Drawing.Point(394, 172);
            this.label_24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_24.Name = "label_24";
            this.label_24.Size = new System.Drawing.Size(24, 17);
            this.label_24.TabIndex = 93;
            this.label_24.Text = "24";
            // 
            // label_25
            // 
            this.label_25.AutoSize = true;
            this.label_25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_25.Location = new System.Drawing.Point(330, 172);
            this.label_25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_25.Name = "label_25";
            this.label_25.Size = new System.Drawing.Size(24, 17);
            this.label_25.TabIndex = 92;
            this.label_25.Text = "25";
            // 
            // label_26
            // 
            this.label_26.AutoSize = true;
            this.label_26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_26.Location = new System.Drawing.Point(265, 172);
            this.label_26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_26.Name = "label_26";
            this.label_26.Size = new System.Drawing.Size(24, 17);
            this.label_26.TabIndex = 91;
            this.label_26.Text = "26";
            // 
            // label_27
            // 
            this.label_27.AutoSize = true;
            this.label_27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_27.Location = new System.Drawing.Point(136, 172);
            this.label_27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_27.Name = "label_27";
            this.label_27.Size = new System.Drawing.Size(24, 17);
            this.label_27.TabIndex = 90;
            this.label_27.Text = "27";
            // 
            // label_28
            // 
            this.label_28.AutoSize = true;
            this.label_28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_28.Location = new System.Drawing.Point(71, 172);
            this.label_28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_28.Name = "label_28";
            this.label_28.Size = new System.Drawing.Size(24, 17);
            this.label_28.TabIndex = 89;
            this.label_28.Text = "28";
            // 
            // label_21
            // 
            this.label_21.AutoSize = true;
            this.label_21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_21.Location = new System.Drawing.Point(586, 261);
            this.label_21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_21.Name = "label_21";
            this.label_21.Size = new System.Drawing.Size(24, 17);
            this.label_21.TabIndex = 88;
            this.label_21.Text = "21";
            // 
            // label_20
            // 
            this.label_20.AutoSize = true;
            this.label_20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_20.Location = new System.Drawing.Point(522, 261);
            this.label_20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_20.Name = "label_20";
            this.label_20.Size = new System.Drawing.Size(24, 17);
            this.label_20.TabIndex = 87;
            this.label_20.Text = "20";
            // 
            // label_19
            // 
            this.label_19.AutoSize = true;
            this.label_19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_19.Location = new System.Drawing.Point(394, 261);
            this.label_19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_19.Name = "label_19";
            this.label_19.Size = new System.Drawing.Size(24, 17);
            this.label_19.TabIndex = 86;
            this.label_19.Text = "19";
            // 
            // label_18
            // 
            this.label_18.AutoSize = true;
            this.label_18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_18.Location = new System.Drawing.Point(330, 261);
            this.label_18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_18.Name = "label_18";
            this.label_18.Size = new System.Drawing.Size(24, 17);
            this.label_18.TabIndex = 85;
            this.label_18.Text = "18";
            // 
            // label_17
            // 
            this.label_17.AutoSize = true;
            this.label_17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_17.Location = new System.Drawing.Point(265, 261);
            this.label_17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_17.Name = "label_17";
            this.label_17.Size = new System.Drawing.Size(24, 17);
            this.label_17.TabIndex = 84;
            this.label_17.Text = "17";
            // 
            // label_16
            // 
            this.label_16.AutoSize = true;
            this.label_16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_16.Location = new System.Drawing.Point(136, 261);
            this.label_16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_16.Name = "label_16";
            this.label_16.Size = new System.Drawing.Size(24, 17);
            this.label_16.TabIndex = 83;
            this.label_16.Text = "16";
            // 
            // label_15
            // 
            this.label_15.AutoSize = true;
            this.label_15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_15.Location = new System.Drawing.Point(71, 261);
            this.label_15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_15.Name = "label_15";
            this.label_15.Size = new System.Drawing.Size(24, 17);
            this.label_15.TabIndex = 82;
            this.label_15.Text = "15";
            // 
            // label_8
            // 
            this.label_8.AutoSize = true;
            this.label_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_8.Location = new System.Drawing.Point(590, 347);
            this.label_8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_8.Name = "label_8";
            this.label_8.Size = new System.Drawing.Size(16, 17);
            this.label_8.TabIndex = 81;
            this.label_8.Text = "8";
            // 
            // label_9
            // 
            this.label_9.AutoSize = true;
            this.label_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_9.Location = new System.Drawing.Point(525, 347);
            this.label_9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_9.Name = "label_9";
            this.label_9.Size = new System.Drawing.Size(16, 17);
            this.label_9.TabIndex = 80;
            this.label_9.Text = "9";
            // 
            // label_10
            // 
            this.label_10.AutoSize = true;
            this.label_10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_10.Location = new System.Drawing.Point(393, 347);
            this.label_10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_10.Name = "label_10";
            this.label_10.Size = new System.Drawing.Size(24, 17);
            this.label_10.TabIndex = 79;
            this.label_10.Text = "10";
            // 
            // label_11
            // 
            this.label_11.AutoSize = true;
            this.label_11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_11.Location = new System.Drawing.Point(329, 347);
            this.label_11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_11.Name = "label_11";
            this.label_11.Size = new System.Drawing.Size(24, 17);
            this.label_11.TabIndex = 78;
            this.label_11.Text = "11";
            // 
            // label_12
            // 
            this.label_12.AutoSize = true;
            this.label_12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_12.Location = new System.Drawing.Point(264, 347);
            this.label_12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_12.Name = "label_12";
            this.label_12.Size = new System.Drawing.Size(24, 17);
            this.label_12.TabIndex = 77;
            this.label_12.Text = "12";
            // 
            // label_13
            // 
            this.label_13.AutoSize = true;
            this.label_13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_13.Location = new System.Drawing.Point(135, 347);
            this.label_13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_13.Name = "label_13";
            this.label_13.Size = new System.Drawing.Size(24, 17);
            this.label_13.TabIndex = 76;
            this.label_13.Text = "13";
            // 
            // label_14
            // 
            this.label_14.AutoSize = true;
            this.label_14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_14.Location = new System.Drawing.Point(70, 347);
            this.label_14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_14.Name = "label_14";
            this.label_14.Size = new System.Drawing.Size(24, 17);
            this.label_14.TabIndex = 75;
            this.label_14.Text = "14";
            // 
            // label_7
            // 
            this.label_7.AutoSize = true;
            this.label_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_7.Location = new System.Drawing.Point(590, 433);
            this.label_7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(16, 17);
            this.label_7.TabIndex = 74;
            this.label_7.Text = "7";
            // 
            // label_6
            // 
            this.label_6.AutoSize = true;
            this.label_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_6.Location = new System.Drawing.Point(525, 433);
            this.label_6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(16, 17);
            this.label_6.TabIndex = 73;
            this.label_6.Text = "6";
            // 
            // label_5
            // 
            this.label_5.AutoSize = true;
            this.label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_5.Location = new System.Drawing.Point(397, 433);
            this.label_5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(16, 17);
            this.label_5.TabIndex = 72;
            this.label_5.Text = "5";
            // 
            // label_4
            // 
            this.label_4.AutoSize = true;
            this.label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_4.Location = new System.Drawing.Point(333, 433);
            this.label_4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(16, 17);
            this.label_4.TabIndex = 71;
            this.label_4.Text = "4";
            // 
            // label_3
            // 
            this.label_3.AutoSize = true;
            this.label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_3.Location = new System.Drawing.Point(268, 433);
            this.label_3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(16, 17);
            this.label_3.TabIndex = 70;
            this.label_3.Text = "3";
            // 
            // label_2
            // 
            this.label_2.AutoSize = true;
            this.label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2.Location = new System.Drawing.Point(139, 433);
            this.label_2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(16, 17);
            this.label_2.TabIndex = 69;
            this.label_2.Text = "2";
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1.Location = new System.Drawing.Point(74, 433);
            this.label_1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(16, 17);
            this.label_1.TabIndex = 68;
            this.label_1.Text = "1";
            // 
            // panel_manHinh
            // 
            this.panel_manHinh.BackColor = System.Drawing.Color.White;
            this.panel_manHinh.Controls.Add(this.pictureBox_panel1_avatarFilm);
            this.panel_manHinh.Controls.Add(this.label_panel_namePhim);
            this.panel_manHinh.Controls.Add(this.label_manHinh);
            this.panel_manHinh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_manHinh.Location = new System.Drawing.Point(0, 475);
            this.panel_manHinh.Margin = new System.Windows.Forms.Padding(2);
            this.panel_manHinh.Name = "panel_manHinh";
            this.panel_manHinh.Size = new System.Drawing.Size(676, 62);
            this.panel_manHinh.TabIndex = 67;
            // 
            // pictureBox_panel1_avatarFilm
            // 
            this.pictureBox_panel1_avatarFilm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_panel1_avatarFilm.Location = new System.Drawing.Point(617, 2);
            this.pictureBox_panel1_avatarFilm.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox_panel1_avatarFilm.Name = "pictureBox_panel1_avatarFilm";
            this.pictureBox_panel1_avatarFilm.Size = new System.Drawing.Size(52, 57);
            this.pictureBox_panel1_avatarFilm.TabIndex = 2;
            this.pictureBox_panel1_avatarFilm.TabStop = false;
            // 
            // label_panel_namePhim
            // 
            this.label_panel_namePhim.AutoSize = true;
            this.label_panel_namePhim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_panel_namePhim.Location = new System.Drawing.Point(2, 25);
            this.label_panel_namePhim.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_panel_namePhim.Name = "label_panel_namePhim";
            this.label_panel_namePhim.Size = new System.Drawing.Size(106, 17);
            this.label_panel_namePhim.TabIndex = 1;
            this.label_panel_namePhim.Text = "Chưa có phim";
            // 
            // label_manHinh
            // 
            this.label_manHinh.AutoSize = true;
            this.label_manHinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_manHinh.Location = new System.Drawing.Point(275, 22);
            this.label_manHinh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_manHinh.Name = "label_manHinh";
            this.label_manHinh.Size = new System.Drawing.Size(161, 24);
            this.label_manHinh.TabIndex = 0;
            this.label_manHinh.Text = "Màn Hình Chiếu";
            // 
            // button_14
            // 
            this.button_14.BackColor = System.Drawing.Color.Transparent;
            this.button_14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_14.BackgroundImage")));
            this.button_14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_14.Location = new System.Drawing.Point(51, 280);
            this.button_14.Margin = new System.Windows.Forms.Padding(2);
            this.button_14.Name = "button_14";
            this.button_14.Size = new System.Drawing.Size(60, 65);
            this.button_14.TabIndex = 66;
            this.button_14.UseVisualStyleBackColor = false;
            this.button_14.Click += new System.EventHandler(this.button_14_Click);
            // 
            // button_15
            // 
            this.button_15.BackColor = System.Drawing.Color.Transparent;
            this.button_15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_15.BackgroundImage")));
            this.button_15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_15.Location = new System.Drawing.Point(51, 191);
            this.button_15.Margin = new System.Windows.Forms.Padding(2);
            this.button_15.Name = "button_15";
            this.button_15.Size = new System.Drawing.Size(60, 65);
            this.button_15.TabIndex = 65;
            this.button_15.UseVisualStyleBackColor = false;
            this.button_15.Click += new System.EventHandler(this.button_15_Click);
            // 
            // button_1
            // 
            this.button_1.BackColor = System.Drawing.Color.Transparent;
            this.button_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_1.BackgroundImage")));
            this.button_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_1.Location = new System.Drawing.Point(51, 366);
            this.button_1.Margin = new System.Windows.Forms.Padding(2);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(60, 65);
            this.button_1.TabIndex = 64;
            this.button_1.UseVisualStyleBackColor = false;
            this.button_1.Click += new System.EventHandler(this.button_1_Click);
            // 
            // button_2
            // 
            this.button_2.BackColor = System.Drawing.Color.Transparent;
            this.button_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_2.BackgroundImage")));
            this.button_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_2.Location = new System.Drawing.Point(116, 366);
            this.button_2.Margin = new System.Windows.Forms.Padding(2);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(60, 65);
            this.button_2.TabIndex = 63;
            this.button_2.UseVisualStyleBackColor = false;
            this.button_2.Click += new System.EventHandler(this.button_2_Click);
            // 
            // button_29
            // 
            this.button_29.BackColor = System.Drawing.Color.Transparent;
            this.button_29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_29.BackgroundImage")));
            this.button_29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_29.Location = new System.Drawing.Point(51, 16);
            this.button_29.Margin = new System.Windows.Forms.Padding(2);
            this.button_29.Name = "button_29";
            this.button_29.Size = new System.Drawing.Size(60, 65);
            this.button_29.TabIndex = 62;
            this.button_29.UseVisualStyleBackColor = false;
            this.button_29.Click += new System.EventHandler(this.button_29_Click);
            // 
            // button_28
            // 
            this.button_28.BackColor = System.Drawing.Color.Transparent;
            this.button_28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_28.BackgroundImage")));
            this.button_28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_28.Location = new System.Drawing.Point(51, 105);
            this.button_28.Margin = new System.Windows.Forms.Padding(2);
            this.button_28.Name = "button_28";
            this.button_28.Size = new System.Drawing.Size(60, 65);
            this.button_28.TabIndex = 61;
            this.button_28.UseVisualStyleBackColor = false;
            this.button_28.Click += new System.EventHandler(this.button_28_Click);
            // 
            // button_27
            // 
            this.button_27.BackColor = System.Drawing.Color.Transparent;
            this.button_27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_27.BackgroundImage")));
            this.button_27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_27.Location = new System.Drawing.Point(116, 105);
            this.button_27.Margin = new System.Windows.Forms.Padding(2);
            this.button_27.Name = "button_27";
            this.button_27.Size = new System.Drawing.Size(60, 65);
            this.button_27.TabIndex = 60;
            this.button_27.UseVisualStyleBackColor = false;
            this.button_27.Click += new System.EventHandler(this.button_27_Click);
            // 
            // button_30
            // 
            this.button_30.BackColor = System.Drawing.Color.Transparent;
            this.button_30.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_30.BackgroundImage")));
            this.button_30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_30.Location = new System.Drawing.Point(116, 16);
            this.button_30.Margin = new System.Windows.Forms.Padding(2);
            this.button_30.Name = "button_30";
            this.button_30.Size = new System.Drawing.Size(60, 65);
            this.button_30.TabIndex = 57;
            this.button_30.UseVisualStyleBackColor = false;
            this.button_30.Click += new System.EventHandler(this.button_30_Click);
            // 
            // button_16
            // 
            this.button_16.BackColor = System.Drawing.Color.Transparent;
            this.button_16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_16.BackgroundImage")));
            this.button_16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_16.Location = new System.Drawing.Point(116, 191);
            this.button_16.Margin = new System.Windows.Forms.Padding(2);
            this.button_16.Name = "button_16";
            this.button_16.Size = new System.Drawing.Size(60, 65);
            this.button_16.TabIndex = 58;
            this.button_16.UseVisualStyleBackColor = false;
            this.button_16.Click += new System.EventHandler(this.button_16_Click);
            // 
            // button_13
            // 
            this.button_13.BackColor = System.Drawing.Color.Transparent;
            this.button_13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_13.BackgroundImage")));
            this.button_13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_13.Location = new System.Drawing.Point(116, 280);
            this.button_13.Margin = new System.Windows.Forms.Padding(2);
            this.button_13.Name = "button_13";
            this.button_13.Size = new System.Drawing.Size(60, 65);
            this.button_13.TabIndex = 59;
            this.button_13.UseVisualStyleBackColor = false;
            this.button_13.Click += new System.EventHandler(this.button_13_Click);
            // 
            // button_32
            // 
            this.button_32.BackColor = System.Drawing.Color.Transparent;
            this.button_32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_32.BackgroundImage")));
            this.button_32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_32.Location = new System.Drawing.Point(244, 16);
            this.button_32.Margin = new System.Windows.Forms.Padding(2);
            this.button_32.Name = "button_32";
            this.button_32.Size = new System.Drawing.Size(60, 65);
            this.button_32.TabIndex = 56;
            this.button_32.UseVisualStyleBackColor = false;
            this.button_32.Click += new System.EventHandler(this.button_32_Click);
            // 
            // button_26
            // 
            this.button_26.BackColor = System.Drawing.Color.Transparent;
            this.button_26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_26.BackgroundImage")));
            this.button_26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_26.Location = new System.Drawing.Point(244, 105);
            this.button_26.Margin = new System.Windows.Forms.Padding(2);
            this.button_26.Name = "button_26";
            this.button_26.Size = new System.Drawing.Size(60, 65);
            this.button_26.TabIndex = 55;
            this.button_26.UseVisualStyleBackColor = false;
            this.button_26.Click += new System.EventHandler(this.button_26_Click);
            // 
            // button_31
            // 
            this.button_31.BackColor = System.Drawing.Color.Transparent;
            this.button_31.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_31.BackgroundImage")));
            this.button_31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_31.Location = new System.Drawing.Point(180, 16);
            this.button_31.Margin = new System.Windows.Forms.Padding(2);
            this.button_31.Name = "button_31";
            this.button_31.Size = new System.Drawing.Size(60, 65);
            this.button_31.TabIndex = 54;
            this.button_31.UseVisualStyleBackColor = false;
            this.button_31.Click += new System.EventHandler(this.button_31_Click);
            // 
            // button_12
            // 
            this.button_12.BackColor = System.Drawing.Color.Transparent;
            this.button_12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_12.BackgroundImage")));
            this.button_12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_12.Location = new System.Drawing.Point(244, 280);
            this.button_12.Margin = new System.Windows.Forms.Padding(2);
            this.button_12.Name = "button_12";
            this.button_12.Size = new System.Drawing.Size(60, 65);
            this.button_12.TabIndex = 53;
            this.button_12.UseVisualStyleBackColor = false;
            this.button_12.Click += new System.EventHandler(this.button_12_Click);
            // 
            // button_17
            // 
            this.button_17.BackColor = System.Drawing.Color.Transparent;
            this.button_17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_17.BackgroundImage")));
            this.button_17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_17.Location = new System.Drawing.Point(244, 191);
            this.button_17.Margin = new System.Windows.Forms.Padding(2);
            this.button_17.Name = "button_17";
            this.button_17.Size = new System.Drawing.Size(60, 65);
            this.button_17.TabIndex = 52;
            this.button_17.UseVisualStyleBackColor = false;
            this.button_17.Click += new System.EventHandler(this.button_17_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button23.BackgroundImage")));
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(244, 191);
            this.button23.Margin = new System.Windows.Forms.Padding(2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(60, 65);
            this.button23.TabIndex = 51;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button_4
            // 
            this.button_4.BackColor = System.Drawing.Color.Transparent;
            this.button_4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_4.BackgroundImage")));
            this.button_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_4.Location = new System.Drawing.Point(309, 366);
            this.button_4.Margin = new System.Windows.Forms.Padding(2);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(60, 65);
            this.button_4.TabIndex = 50;
            this.button_4.UseVisualStyleBackColor = false;
            this.button_4.Click += new System.EventHandler(this.button_4_Click);
            // 
            // button_11
            // 
            this.button_11.BackColor = System.Drawing.Color.Transparent;
            this.button_11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_11.BackgroundImage")));
            this.button_11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_11.Location = new System.Drawing.Point(309, 280);
            this.button_11.Margin = new System.Windows.Forms.Padding(2);
            this.button_11.Name = "button_11";
            this.button_11.Size = new System.Drawing.Size(60, 65);
            this.button_11.TabIndex = 49;
            this.button_11.UseVisualStyleBackColor = false;
            this.button_11.Click += new System.EventHandler(this.button_11_Click);
            // 
            // button_3
            // 
            this.button_3.BackColor = System.Drawing.Color.Transparent;
            this.button_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_3.BackgroundImage")));
            this.button_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_3.Location = new System.Drawing.Point(244, 366);
            this.button_3.Margin = new System.Windows.Forms.Padding(2);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(60, 65);
            this.button_3.TabIndex = 48;
            this.button_3.UseVisualStyleBackColor = false;
            this.button_3.Click += new System.EventHandler(this.button_3_Click);
            // 
            // button_25
            // 
            this.button_25.BackColor = System.Drawing.Color.Transparent;
            this.button_25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_25.BackgroundImage")));
            this.button_25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_25.Location = new System.Drawing.Point(309, 105);
            this.button_25.Margin = new System.Windows.Forms.Padding(2);
            this.button_25.Name = "button_25";
            this.button_25.Size = new System.Drawing.Size(60, 65);
            this.button_25.TabIndex = 47;
            this.button_25.UseVisualStyleBackColor = false;
            this.button_25.Click += new System.EventHandler(this.button_25_Click);
            // 
            // button_33
            // 
            this.button_33.BackColor = System.Drawing.Color.Transparent;
            this.button_33.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_33.BackgroundImage")));
            this.button_33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_33.Location = new System.Drawing.Point(309, 16);
            this.button_33.Margin = new System.Windows.Forms.Padding(2);
            this.button_33.Name = "button_33";
            this.button_33.Size = new System.Drawing.Size(60, 65);
            this.button_33.TabIndex = 46;
            this.button_33.UseVisualStyleBackColor = false;
            this.button_33.Click += new System.EventHandler(this.button_33_Click);
            // 
            // button_18
            // 
            this.button_18.BackColor = System.Drawing.Color.Transparent;
            this.button_18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_18.BackgroundImage")));
            this.button_18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_18.Location = new System.Drawing.Point(309, 191);
            this.button_18.Margin = new System.Windows.Forms.Padding(2);
            this.button_18.Name = "button_18";
            this.button_18.Size = new System.Drawing.Size(60, 65);
            this.button_18.TabIndex = 45;
            this.button_18.UseVisualStyleBackColor = false;
            this.button_18.Click += new System.EventHandler(this.button_18_Click);
            // 
            // button_5
            // 
            this.button_5.BackColor = System.Drawing.Color.Transparent;
            this.button_5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_5.BackgroundImage")));
            this.button_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_5.Location = new System.Drawing.Point(374, 366);
            this.button_5.Margin = new System.Windows.Forms.Padding(2);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(60, 65);
            this.button_5.TabIndex = 44;
            this.button_5.UseVisualStyleBackColor = false;
            this.button_5.Click += new System.EventHandler(this.button_5_Click);
            // 
            // button_19
            // 
            this.button_19.BackColor = System.Drawing.Color.Transparent;
            this.button_19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_19.BackgroundImage")));
            this.button_19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_19.Location = new System.Drawing.Point(374, 191);
            this.button_19.Margin = new System.Windows.Forms.Padding(2);
            this.button_19.Name = "button_19";
            this.button_19.Size = new System.Drawing.Size(60, 65);
            this.button_19.TabIndex = 43;
            this.button_19.UseVisualStyleBackColor = false;
            this.button_19.Click += new System.EventHandler(this.button_19_Click);
            // 
            // button_24
            // 
            this.button_24.BackColor = System.Drawing.Color.Transparent;
            this.button_24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_24.BackgroundImage")));
            this.button_24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_24.Location = new System.Drawing.Point(374, 105);
            this.button_24.Margin = new System.Windows.Forms.Padding(2);
            this.button_24.Name = "button_24";
            this.button_24.Size = new System.Drawing.Size(60, 65);
            this.button_24.TabIndex = 41;
            this.button_24.UseVisualStyleBackColor = false;
            this.button_24.Click += new System.EventHandler(this.button_24_Click);
            // 
            // button_35
            // 
            this.button_35.BackColor = System.Drawing.Color.Transparent;
            this.button_35.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_35.BackgroundImage")));
            this.button_35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_35.Location = new System.Drawing.Point(438, 16);
            this.button_35.Margin = new System.Windows.Forms.Padding(2);
            this.button_35.Name = "button_35";
            this.button_35.Size = new System.Drawing.Size(60, 65);
            this.button_35.TabIndex = 40;
            this.button_35.UseVisualStyleBackColor = false;
            this.button_35.Click += new System.EventHandler(this.button_35_Click);
            // 
            // button_6
            // 
            this.button_6.BackColor = System.Drawing.Color.Transparent;
            this.button_6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_6.BackgroundImage")));
            this.button_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_6.Location = new System.Drawing.Point(502, 366);
            this.button_6.Margin = new System.Windows.Forms.Padding(2);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(60, 65);
            this.button_6.TabIndex = 38;
            this.button_6.UseVisualStyleBackColor = false;
            this.button_6.Click += new System.EventHandler(this.button_6_Click);
            // 
            // button_34
            // 
            this.button_34.BackColor = System.Drawing.Color.Transparent;
            this.button_34.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_34.BackgroundImage")));
            this.button_34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_34.Location = new System.Drawing.Point(374, 16);
            this.button_34.Margin = new System.Windows.Forms.Padding(2);
            this.button_34.Name = "button_34";
            this.button_34.Size = new System.Drawing.Size(60, 65);
            this.button_34.TabIndex = 39;
            this.button_34.UseVisualStyleBackColor = false;
            this.button_34.Click += new System.EventHandler(this.button_34_Click);
            // 
            // button_9
            // 
            this.button_9.BackColor = System.Drawing.Color.Transparent;
            this.button_9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_9.BackgroundImage")));
            this.button_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_9.Location = new System.Drawing.Point(502, 280);
            this.button_9.Margin = new System.Windows.Forms.Padding(2);
            this.button_9.Name = "button_9";
            this.button_9.Size = new System.Drawing.Size(60, 65);
            this.button_9.TabIndex = 37;
            this.button_9.UseVisualStyleBackColor = false;
            this.button_9.Click += new System.EventHandler(this.button_9_Click);
            // 
            // button_20
            // 
            this.button_20.BackColor = System.Drawing.Color.Transparent;
            this.button_20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_20.BackgroundImage")));
            this.button_20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_20.Location = new System.Drawing.Point(502, 191);
            this.button_20.Margin = new System.Windows.Forms.Padding(2);
            this.button_20.Name = "button_20";
            this.button_20.Size = new System.Drawing.Size(60, 65);
            this.button_20.TabIndex = 36;
            this.button_20.UseVisualStyleBackColor = false;
            this.button_20.Click += new System.EventHandler(this.button_20_Click);
            // 
            // button_23
            // 
            this.button_23.BackColor = System.Drawing.Color.Transparent;
            this.button_23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_23.BackgroundImage")));
            this.button_23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_23.Location = new System.Drawing.Point(502, 105);
            this.button_23.Margin = new System.Windows.Forms.Padding(2);
            this.button_23.Name = "button_23";
            this.button_23.Size = new System.Drawing.Size(60, 65);
            this.button_23.TabIndex = 35;
            this.button_23.UseVisualStyleBackColor = false;
            this.button_23.Click += new System.EventHandler(this.button_23_Click);
            // 
            // button_36
            // 
            this.button_36.BackColor = System.Drawing.Color.Transparent;
            this.button_36.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_36.BackgroundImage")));
            this.button_36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_36.Location = new System.Drawing.Point(502, 16);
            this.button_36.Margin = new System.Windows.Forms.Padding(2);
            this.button_36.Name = "button_36";
            this.button_36.Size = new System.Drawing.Size(60, 65);
            this.button_36.TabIndex = 34;
            this.button_36.UseVisualStyleBackColor = false;
            this.button_36.Click += new System.EventHandler(this.button_36_Click);
            // 
            // button_37
            // 
            this.button_37.BackColor = System.Drawing.Color.Transparent;
            this.button_37.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_37.BackgroundImage")));
            this.button_37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_37.Location = new System.Drawing.Point(567, 16);
            this.button_37.Margin = new System.Windows.Forms.Padding(2);
            this.button_37.Name = "button_37";
            this.button_37.Size = new System.Drawing.Size(60, 65);
            this.button_37.TabIndex = 33;
            this.button_37.UseVisualStyleBackColor = false;
            this.button_37.Click += new System.EventHandler(this.button_37_Click);
            // 
            // button_22
            // 
            this.button_22.BackColor = System.Drawing.Color.Transparent;
            this.button_22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_22.BackgroundImage")));
            this.button_22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_22.Location = new System.Drawing.Point(567, 105);
            this.button_22.Margin = new System.Windows.Forms.Padding(2);
            this.button_22.Name = "button_22";
            this.button_22.Size = new System.Drawing.Size(60, 65);
            this.button_22.TabIndex = 32;
            this.button_22.UseVisualStyleBackColor = false;
            this.button_22.Click += new System.EventHandler(this.button_22_Click);
            // 
            // button_21
            // 
            this.button_21.BackColor = System.Drawing.Color.Transparent;
            this.button_21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_21.BackgroundImage")));
            this.button_21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_21.Location = new System.Drawing.Point(567, 191);
            this.button_21.Margin = new System.Windows.Forms.Padding(2);
            this.button_21.Name = "button_21";
            this.button_21.Size = new System.Drawing.Size(60, 65);
            this.button_21.TabIndex = 31;
            this.button_21.UseVisualStyleBackColor = false;
            this.button_21.Click += new System.EventHandler(this.button_21_Click);
            // 
            // button_7
            // 
            this.button_7.BackColor = System.Drawing.Color.Transparent;
            this.button_7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_7.BackgroundImage")));
            this.button_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_7.Location = new System.Drawing.Point(567, 366);
            this.button_7.Margin = new System.Windows.Forms.Padding(2);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(60, 65);
            this.button_7.TabIndex = 30;
            this.button_7.UseVisualStyleBackColor = false;
            this.button_7.Click += new System.EventHandler(this.button_7_Click);
            // 
            // button_8
            // 
            this.button_8.BackColor = System.Drawing.Color.Transparent;
            this.button_8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_8.BackgroundImage")));
            this.button_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_8.Location = new System.Drawing.Point(567, 280);
            this.button_8.Margin = new System.Windows.Forms.Padding(2);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(60, 65);
            this.button_8.TabIndex = 29;
            this.button_8.UseVisualStyleBackColor = false;
            this.button_8.Click += new System.EventHandler(this.button_8_Click);
            // 
            // button_10
            // 
            this.button_10.BackColor = System.Drawing.Color.Transparent;
            this.button_10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_10.BackgroundImage")));
            this.button_10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_10.Location = new System.Drawing.Point(374, 280);
            this.button_10.Margin = new System.Windows.Forms.Padding(2);
            this.button_10.Name = "button_10";
            this.button_10.Size = new System.Drawing.Size(60, 65);
            this.button_10.TabIndex = 42;
            this.button_10.UseVisualStyleBackColor = false;
            this.button_10.Click += new System.EventHandler(this.button_10_Click);
            // 
            // panel_2_addInforFilm
            // 
            this.panel_2_addInforFilm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_2_addInforFilm.BackColor = System.Drawing.Color.LightCyan;
            this.panel_2_addInforFilm.Controls.Add(this.comboBox_thongTin_trangThai);
            this.panel_2_addInforFilm.Controls.Add(this.button_thongTin_xoaPhim);
            this.panel_2_addInforFilm.Controls.Add(this.button_thongTin_themVao);
            this.panel_2_addInforFilm.Controls.Add(this.pictureBox_thongTin_anh);
            this.panel_2_addInforFilm.Controls.Add(this.textBox_thongTin_thongTin);
            this.panel_2_addInforFilm.Controls.Add(this.label7);
            this.panel_2_addInforFilm.Controls.Add(this.label_trangthai);
            this.panel_2_addInforFilm.Controls.Add(this.textBox_thongTin_tacGia);
            this.panel_2_addInforFilm.Controls.Add(this.label_tacgia);
            this.panel_2_addInforFilm.Controls.Add(this.textBox_thongTin_phim);
            this.panel_2_addInforFilm.Controls.Add(this.label_tenphim);
            this.panel_2_addInforFilm.Location = new System.Drawing.Point(212, 398);
            this.panel_2_addInforFilm.Margin = new System.Windows.Forms.Padding(2);
            this.panel_2_addInforFilm.Name = "panel_2_addInforFilm";
            this.panel_2_addInforFilm.Size = new System.Drawing.Size(674, 157);
            this.panel_2_addInforFilm.TabIndex = 5;
            this.panel_2_addInforFilm.Visible = false;
            // 
            // comboBox_thongTin_trangThai
            // 
            this.comboBox_thongTin_trangThai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_thongTin_trangThai.FormattingEnabled = true;
            this.comboBox_thongTin_trangThai.Items.AddRange(new object[] {
            "Sắp chiếu",
            "Đang chiếu",
            "Ngừng chiếu"});
            this.comboBox_thongTin_trangThai.Location = new System.Drawing.Point(122, 70);
            this.comboBox_thongTin_trangThai.Name = "comboBox_thongTin_trangThai";
            this.comboBox_thongTin_trangThai.Size = new System.Drawing.Size(377, 23);
            this.comboBox_thongTin_trangThai.TabIndex = 11;
            // 
            // button_thongTin_xoaPhim
            // 
            this.button_thongTin_xoaPhim.BackColor = System.Drawing.Color.DarkCyan;
            this.button_thongTin_xoaPhim.ForeColor = System.Drawing.Color.White;
            this.button_thongTin_xoaPhim.Location = new System.Drawing.Point(608, 57);
            this.button_thongTin_xoaPhim.Name = "button_thongTin_xoaPhim";
            this.button_thongTin_xoaPhim.Size = new System.Drawing.Size(35, 28);
            this.button_thongTin_xoaPhim.TabIndex = 10;
            this.button_thongTin_xoaPhim.Text = "-";
            this.button_thongTin_xoaPhim.UseVisualStyleBackColor = false;
            this.button_thongTin_xoaPhim.Click += new System.EventHandler(this.button_thongTin_xoaPhim_Click);
            // 
            // button_thongTin_themVao
            // 
            this.button_thongTin_themVao.BackColor = System.Drawing.Color.DarkCyan;
            this.button_thongTin_themVao.ForeColor = System.Drawing.Color.White;
            this.button_thongTin_themVao.Location = new System.Drawing.Point(608, 15);
            this.button_thongTin_themVao.Name = "button_thongTin_themVao";
            this.button_thongTin_themVao.Size = new System.Drawing.Size(35, 28);
            this.button_thongTin_themVao.TabIndex = 9;
            this.button_thongTin_themVao.Text = "+";
            this.button_thongTin_themVao.UseVisualStyleBackColor = false;
            this.button_thongTin_themVao.Click += new System.EventHandler(this.button_thongTin_themVao_Click);
            // 
            // pictureBox_thongTin_anh
            // 
            this.pictureBox_thongTin_anh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_thongTin_anh.Location = new System.Drawing.Point(518, 10);
            this.pictureBox_thongTin_anh.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox_thongTin_anh.Name = "pictureBox_thongTin_anh";
            this.pictureBox_thongTin_anh.Size = new System.Drawing.Size(75, 81);
            this.pictureBox_thongTin_anh.TabIndex = 8;
            this.pictureBox_thongTin_anh.TabStop = false;
            this.pictureBox_thongTin_anh.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBox_thongTin_thongTin
            // 
            this.textBox_thongTin_thongTin.Location = new System.Drawing.Point(122, 102);
            this.textBox_thongTin_thongTin.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_thongTin_thongTin.Multiline = true;
            this.textBox_thongTin_thongTin.Name = "textBox_thongTin_thongTin";
            this.textBox_thongTin_thongTin.Size = new System.Drawing.Size(522, 46);
            this.textBox_thongTin_thongTin.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label7.Location = new System.Drawing.Point(31, 101);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Thông tin";
            // 
            // label_trangthai
            // 
            this.label_trangthai.AutoSize = true;
            this.label_trangthai.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_trangthai.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label_trangthai.Location = new System.Drawing.Point(31, 72);
            this.label_trangthai.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_trangthai.Name = "label_trangthai";
            this.label_trangthai.Size = new System.Drawing.Size(77, 18);
            this.label_trangthai.TabIndex = 5;
            this.label_trangthai.Text = "Trạng thái";
            // 
            // textBox_thongTin_tacGia
            // 
            this.textBox_thongTin_tacGia.Location = new System.Drawing.Point(122, 40);
            this.textBox_thongTin_tacGia.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_thongTin_tacGia.Multiline = true;
            this.textBox_thongTin_tacGia.Name = "textBox_thongTin_tacGia";
            this.textBox_thongTin_tacGia.Size = new System.Drawing.Size(377, 22);
            this.textBox_thongTin_tacGia.TabIndex = 3;
            // 
            // label_tacgia
            // 
            this.label_tacgia.AutoSize = true;
            this.label_tacgia.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_tacgia.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label_tacgia.Location = new System.Drawing.Point(31, 43);
            this.label_tacgia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_tacgia.Name = "label_tacgia";
            this.label_tacgia.Size = new System.Drawing.Size(57, 18);
            this.label_tacgia.TabIndex = 2;
            this.label_tacgia.Text = "Tác giả";
            // 
            // textBox_thongTin_phim
            // 
            this.textBox_thongTin_phim.Location = new System.Drawing.Point(122, 10);
            this.textBox_thongTin_phim.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_thongTin_phim.Multiline = true;
            this.textBox_thongTin_phim.Name = "textBox_thongTin_phim";
            this.textBox_thongTin_phim.Size = new System.Drawing.Size(377, 22);
            this.textBox_thongTin_phim.TabIndex = 1;
            this.textBox_thongTin_phim.Click += new System.EventHandler(this.textBox_thongTin_phim_Click);
            this.textBox_thongTin_phim.TextChanged += new System.EventHandler(this.textBox_thongTin_phim_TextChanged);
            // 
            // label_tenphim
            // 
            this.label_tenphim.AutoSize = true;
            this.label_tenphim.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_tenphim.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label_tenphim.Location = new System.Drawing.Point(31, 12);
            this.label_tenphim.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_tenphim.Name = "label_tenphim";
            this.label_tenphim.Size = new System.Drawing.Size(70, 18);
            this.label_tenphim.TabIndex = 0;
            this.label_tenphim.Text = "Tên phim";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox2.Controls.Add(this.button_themPhim_themPhim);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox2.Location = new System.Drawing.Point(8, 345);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(197, 63);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thêm Phim";
            // 
            // button_themPhim_themPhim
            // 
            this.button_themPhim_themPhim.BackColor = System.Drawing.Color.DarkCyan;
            this.button_themPhim_themPhim.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_themPhim_themPhim.ForeColor = System.Drawing.Color.White;
            this.button_themPhim_themPhim.Location = new System.Drawing.Point(5, 23);
            this.button_themPhim_themPhim.Margin = new System.Windows.Forms.Padding(2);
            this.button_themPhim_themPhim.Name = "button_themPhim_themPhim";
            this.button_themPhim_themPhim.Size = new System.Drawing.Size(176, 28);
            this.button_themPhim_themPhim.TabIndex = 15;
            this.button_themPhim_themPhim.Text = "Thêm phim mới";
            this.button_themPhim_themPhim.UseVisualStyleBackColor = false;
            this.button_themPhim_themPhim.Click += new System.EventHandler(this.button_themPhim_themPhim_Click);
            // 
            // label_dadat
            // 
            this.label_dadat.AutoSize = true;
            this.label_dadat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dadat.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_dadat.Location = new System.Drawing.Point(5, 154);
            this.label_dadat.Name = "label_dadat";
            this.label_dadat.Size = new System.Drawing.Size(43, 15);
            this.label_dadat.TabIndex = 13;
            this.label_dadat.Text = "Đã đặt";
            // 
            // textBox_soGheDaDat
            // 
            this.textBox_soGheDaDat.Enabled = false;
            this.textBox_soGheDaDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_soGheDaDat.Location = new System.Drawing.Point(51, 152);
            this.textBox_soGheDaDat.Name = "textBox_soGheDaDat";
            this.textBox_soGheDaDat.ReadOnly = true;
            this.textBox_soGheDaDat.Size = new System.Drawing.Size(30, 21);
            this.textBox_soGheDaDat.TabIndex = 14;
            // 
            // label_controng
            // 
            this.label_controng.AutoSize = true;
            this.label_controng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_controng.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_controng.Location = new System.Drawing.Point(84, 155);
            this.label_controng.Name = "label_controng";
            this.label_controng.Size = new System.Drawing.Size(60, 15);
            this.label_controng.TabIndex = 15;
            this.label_controng.Text = "Còn trống";
            // 
            // textBox_soGheChuaDat
            // 
            this.textBox_soGheChuaDat.Enabled = false;
            this.textBox_soGheChuaDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_soGheChuaDat.Location = new System.Drawing.Point(147, 153);
            this.textBox_soGheChuaDat.Name = "textBox_soGheChuaDat";
            this.textBox_soGheChuaDat.ReadOnly = true;
            this.textBox_soGheChuaDat.Size = new System.Drawing.Size(30, 21);
            this.textBox_soGheChuaDat.TabIndex = 16;
            // 
            // BookTickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(891, 565);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_suatchieu);
            this.Controls.Add(this.groupBox_datve);
            this.Controls.Add(this.panel_2_addInforFilm);
            this.Controls.Add(this.panel_seatsMap);
            this.Controls.Add(this.listView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BookTickets";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BookTickets";
            this.Load += new System.EventHandler(this.BookTickets_Load);
            this.SizeChanged += new System.EventHandler(this.BookTickets_SizeChanged);
            this.groupBox_datve.ResumeLayout(false);
            this.groupBox_datve.PerformLayout();
            this.groupBox_suatchieu.ResumeLayout(false);
            this.groupBox_suatchieu.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_seatsMap.ResumeLayout(false);
            this.panel_seatsMap.PerformLayout();
            this.panel_manHinh.ResumeLayout(false);
            this.panel_manHinh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_panel1_avatarFilm)).EndInit();
            this.panel_2_addInforFilm.ResumeLayout(false);
            this.panel_2_addInforFilm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_thongTin_anh)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_datve;
        private System.Windows.Forms.GroupBox groupBox_suatchieu;
        private System.Windows.Forms.ComboBox comboBox_suat;
        private System.Windows.Forms.ComboBox comboBox_phim;
        private System.Windows.Forms.Label label_suat;
        private System.Windows.Forms.Label label_datve_phim;
        private System.Windows.Forms.Label label_datve_ngay;
        private System.Windows.Forms.DateTimePicker dateTimePicker_datve;
        private System.Windows.Forms.Label label_thoigian;
        private System.Windows.Forms.Label label_suat_phim;
        private System.Windows.Forms.DateTimePicker dateTimePicker_danhMuc_suat;
        private System.Windows.Forms.Label label_suat_ngay;
        private System.Windows.Forms.Button button_datve;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ComboBox comboBox_rap;
        private System.Windows.Forms.Label label_rap;
        private System.Windows.Forms.Label label_soghe;
        private System.Windows.Forms.TextBox textBox_soghe;
        private System.Windows.Forms.Button button_huyve;
        private System.Windows.Forms.ComboBox comboBox_suatChieu_phim;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_xemGhe;
        private System.Windows.Forms.ComboBox comboBox_soDo_rap;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_soDo_suat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_seatsMap;
        private System.Windows.Forms.Button button_14;
        private System.Windows.Forms.Button button_15;
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button button_2;
        private System.Windows.Forms.Button button_29;
        private System.Windows.Forms.Button button_28;
        private System.Windows.Forms.Button button_27;
        private System.Windows.Forms.Button button_30;
        private System.Windows.Forms.Button button_16;
        private System.Windows.Forms.Button button_13;
        private System.Windows.Forms.Button button_32;
        private System.Windows.Forms.Button button_26;
        private System.Windows.Forms.Button button_31;
        private System.Windows.Forms.Button button_12;
        private System.Windows.Forms.Button button_17;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button_4;
        private System.Windows.Forms.Button button_11;
        private System.Windows.Forms.Button button_3;
        private System.Windows.Forms.Button button_25;
        private System.Windows.Forms.Button button_33;
        private System.Windows.Forms.Button button_18;
        private System.Windows.Forms.Button button_5;
        private System.Windows.Forms.Button button_19;
        private System.Windows.Forms.Button button_24;
        private System.Windows.Forms.Button button_35;
        private System.Windows.Forms.Button button_6;
        private System.Windows.Forms.Button button_34;
        private System.Windows.Forms.Button button_9;
        private System.Windows.Forms.Button button_20;
        private System.Windows.Forms.Button button_23;
        private System.Windows.Forms.Button button_36;
        private System.Windows.Forms.Button button_37;
        private System.Windows.Forms.Button button_22;
        private System.Windows.Forms.Button button_21;
        private System.Windows.Forms.Button button_7;
        private System.Windows.Forms.Button button_8;
        private System.Windows.Forms.Button button_10;
        private System.Windows.Forms.Panel panel_manHinh;
        private System.Windows.Forms.Label label_manHinh;
        private System.Windows.Forms.Label label_35;
        private System.Windows.Forms.Label label_31;
        private System.Windows.Forms.Label label_37;
        private System.Windows.Forms.Label label_36;
        private System.Windows.Forms.Label label_34;
        private System.Windows.Forms.Label label_33;
        private System.Windows.Forms.Label label_32;
        private System.Windows.Forms.Label label_30;
        private System.Windows.Forms.Label label_29;
        private System.Windows.Forms.Label label_22;
        private System.Windows.Forms.Label label_23;
        private System.Windows.Forms.Label label_24;
        private System.Windows.Forms.Label label_25;
        private System.Windows.Forms.Label label_26;
        private System.Windows.Forms.Label label_27;
        private System.Windows.Forms.Label label_28;
        private System.Windows.Forms.Label label_21;
        private System.Windows.Forms.Label label_20;
        private System.Windows.Forms.Label label_19;
        private System.Windows.Forms.Label label_18;
        private System.Windows.Forms.Label label_17;
        private System.Windows.Forms.Label label_16;
        private System.Windows.Forms.Label label_15;
        private System.Windows.Forms.Label label_8;
        private System.Windows.Forms.Label label_9;
        private System.Windows.Forms.Label label_10;
        private System.Windows.Forms.Label label_11;
        private System.Windows.Forms.Label label_12;
        private System.Windows.Forms.Label label_13;
        private System.Windows.Forms.Label label_14;
        private System.Windows.Forms.Label label_7;
        private System.Windows.Forms.Label label_6;
        private System.Windows.Forms.Label label_5;
        private System.Windows.Forms.Label label_4;
        private System.Windows.Forms.Label label_3;
        private System.Windows.Forms.Label label_2;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.Button button_huy_suatchieu;
        private System.Windows.Forms.Button button_them_suatChieu;
        private System.Windows.Forms.ComboBox comboBox_suatChieu_rap;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_suatChieu;
        private System.Windows.Forms.Label label_panel_namePhim;
        private System.Windows.Forms.PictureBox pictureBox_panel1_avatarFilm;
        private System.Windows.Forms.Panel panel_2_addInforFilm;
        private System.Windows.Forms.PictureBox pictureBox_thongTin_anh;
        private System.Windows.Forms.TextBox textBox_thongTin_thongTin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_trangthai;
        private System.Windows.Forms.TextBox textBox_thongTin_tacGia;
        private System.Windows.Forms.Label label_tacgia;
        private System.Windows.Forms.TextBox textBox_thongTin_phim;
        private System.Windows.Forms.Label label_tenphim;
        private System.Windows.Forms.ComboBox comboBox_thongTin_trangThai;
        private System.Windows.Forms.Button button_thongTin_xoaPhim;
        private System.Windows.Forms.Button button_thongTin_themVao;
        private System.Windows.Forms.DateTimePicker dateTimePicker_soDo_thoiGian;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_themPhim_themPhim;
        private System.Windows.Forms.TextBox textBox_soGheChuaDat;
        private System.Windows.Forms.Label label_controng;
        private System.Windows.Forms.TextBox textBox_soGheDaDat;
        private System.Windows.Forms.Label label_dadat;
    }
}

