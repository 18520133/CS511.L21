﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaiTH1.Properties;

namespace BaiTH1
{
    public partial class BookTickets : Form
    {
        public BookTickets()
        {
            InitializeComponent();
        }

        // khởi tạo kiểu phim
        struct movie
        {
            public string name { get; set; }
            public string staus { get; set; }
            public string author { get; set; }
            public string infor { get; set; }
            public List<showDayTime> showDays { get; set; }
        }

        // khởi tạo ngày
        struct showDayTime
        {
            public string day { get; set; }
            public List<showTimeFilm> showTimes { get; set; }
        }

        // khởi tạo thời gian và địa điểm chiếu
        struct showTimeFilm
        {
            public string time { get; set; }
            public List<int> theaters { get; set; }
            public List<bool> seats_1 { get; set; }
            public List<bool> seats_2 { get; set; }
            public List<bool> seats_3 { get; set; }
        }

        // khởi tạo biến
        List<movie> moviesList = new List<movie>();
        ImageList imageListMovies = new ImageList();
        int selectedShowTime = -1;
        int selectedMovie = -1;
        List<Button> lstBtn = new List<Button>();
        List<Label> lstLb = new List<Label>();
        List<int> lstSeats = new List<int>();
        bool firstTime = true;
        Size defautSize;
        //bool booking = false;
        List<Button> lstChooseBtn = new List<Button>();
        List<string> lstTimes = new List<string>()
        {
            "07:00", "09:00" ,"11:00", "13:00", "15:00", "17:00"
        };

        // tạo thời gian và địa điểm chiếu
        // vì sao phải khởi tạo thời gian chiếu, vì sao này khi thêm mới phim vào nếu chưa được khai báo
        // các giá trị thì nó sẽ lỗi
        showTimeFilm addSeatsToShowTime(int theater, showTimeFilm showTime, List<int> booked = null)
        {
            // nếu là rạp 1
            if (theater == 1)
            {
                showTime.seats_1 = new List<bool>();
                for (int i = 0; i < 37; i++)// đổi số ghế tùy theo sơ đồ 
                {
                    // nếu như không có ghế nào được book cho tất cả bàng false
                    if (booked == null)
                        showTime.seats_1.Add(false);
                    else
                    {
                        // kiểm tra i trong các ghế đã được book và gán i = true
                        if (booked.Contains(i))
                            showTime.seats_1.Add(true);
                        else
                            showTime.seats_1.Add(false);
                    }
                }
            }
            else if (theater == 2)
            {
                showTime.seats_2 = new List<bool>();
                for (int i = 0; i < 37; i++) // đổi số ghế tùy theo sơ đồ 
                {
                    if (booked == null)
                        showTime.seats_2.Add(false);
                    else
                    {
                        if (booked.Contains(i))
                            showTime.seats_2.Add(true);
                        else
                            showTime.seats_2.Add(false);
                    }
                }
            }
            else if (theater == 3 )
            {
                showTime.seats_3 = new List<bool>();
                for (int i = 0; i < 37; i++)// đổi số ghế tùy theo sơ đồ 
                {
                    if (booked == null)
                        showTime.seats_3.Add(false);
                    else
                    {
                        if (booked.Contains(i))
                            showTime.seats_3.Add(true);
                        else
                            showTime.seats_3.Add(false);
                    }
                }
            }
            return showTime;
        }


        bool checkHasTime(string time, int theater, string day)
        {
            foreach(movie film in moviesList)
            {
                foreach(showDayTime sd in film.showDays)
                {
                    if(sd.day == day)
                    {
                        foreach(showTimeFilm st in sd.showTimes)
                        {
                            if (st.time == time)
                            {
                                if ((theater == 1 && st.seats_1 != null) || (theater == 2 && st.seats_2 != null) || (theater == 3 && st.seats_3 != null))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        // hàm add thời gian và rạp chiếu vào data
        showDayTime addShowTime(string time,int theater ,showDayTime days,List<int> booked = null)
        {
            if (checkHasTime(time, theater,days.day))
            {
                MessageBox.Show("Đã tồn tại suất chiếu và rạp chiếu trong ngày!!!");
            }
            else
            {
                // tìm xem đã có thời gian chiếu chưa 
                int flagTime = -1;
                for (int i = 0; i < days.showTimes.Count; i++)
                {
                    if (days.showTimes[i].time == time)
                    {
                        flagTime = i;
                        break;
                    }
                }

                // nếu đã có rồi
                if (flagTime != -1)
                {
                    days.showTimes[flagTime] = addSeatsToShowTime(theater, days.showTimes[flagTime], booked);
                }
                else
                {
                    showTimeFilm newTime = new showTimeFilm();
                    newTime.time = time;
                    newTime = addSeatsToShowTime(theater, newTime, booked);
                    days.showTimes.Add(newTime);
                }
            }
            return days;
        }

        // thêm day
        void addShowDay(string time, int theater, string day, movie film, List<int> booked = null)
        {
            for(int i  = 0; i < film.showDays.Count; i++)
            {
                if (film.showDays[i].day == day)
                {
                    //
                    film.showDays[i] = addShowTime(time, theater, film.showDays[i], booked);
                    return;
                }
            }
            showDayTime newDay = new showDayTime();
            newDay.day = day;
            newDay.showTimes = new List<showTimeFilm>();
            newDay = addShowTime(time, theater, newDay, booked);
            film.showDays.Add(newDay);
        }

        // khởi tạo database ban đầu
        void createDatabase()
        {
            movie newFilm = new movie();
            newFilm.name = "bố già";
            newFilm.staus = "Đang chiếu";
            newFilm.infor = "Bố già là câu chuyện thường nhật về một gia đình ở một xóm lao động nghèo tại thành phố Hồ Chí Minh, ở đó có bộ tứ anh em Giàu, Sang, Phú, Quý. Ba Sang (Trấn Thành) là cha đơn thân, một mình nuôi hai con Quắn và Bù Tọt, trong đó đứa con trai đầu hơn 20 tuổi tên Quắn (Tuấn Trần) là một YouTuber kiếm tiền từ những lượt xem trên YouTube. Tính ông cần kiệm còn Quắn có phần bốc đồng, nông nổi, có thể mua chiếc quần hay đôi giày giá hơn 10 triệu đồng. Ông hay bao đồng, thường can thiệp vào chuyện láng giềng và cố gắng giúp đỡ tất cả mọi người xung quanh, còn Quắn thì cho rằng mỗi người có một cuộc sống riêng. Dù yêu thương nhau nhưng khoảng cách giữa các thế hệ đã dẫn đến những mâu thuẫn cha con nảy sinh";
            newFilm.author = "Vũ Ngọc Đăng, Trấn Thành";

            newFilm.showDays = new List<showDayTime>();

            // các ghế đã được đặt trong rạp 1
            List<int> booked = new List<int> { 1, 8, 10, 11, 23, 6 };
            addShowDay("07:00", 1, dateTimePicker_danhMuc_suat.Value.Day.ToString(), newFilm, booked);

            //// tương tự với rạp 3
            booked = new List<int> { 3, 4, 20, 21, 22 };
            addShowDay(lstTimes[0], 3, dateTimePicker_danhMuc_suat.Value.Day.ToString(), newFilm, booked);

            //chưa được book thì không cần truyền biến book
            addShowDay(lstTimes[2], 3, dateTimePicker_danhMuc_suat.Value.Day.ToString(), newFilm);


            // tương tự với 17:00
            addShowDay(lstTimes[5], 1, dateTimePicker_danhMuc_suat.Value.Day.ToString(), newFilm);
            addShowDay(lstTimes[0], 2, dateTimePicker_danhMuc_suat.Value.Day.ToString(), newFilm);

            // add to list database
            moviesList.Add(newFilm);
            // add vào listview 
            imageListMovies.Images.Add(Resources.Bố_già);
        }

        // lấy giá trị giá trị đang được chọn ở listview
        void getItem()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                if(checkIsShowTime)
                {
                    selectedShowTime = listView1.SelectedItems[0].Index;
                    string[] tmp = showTimesMovies[selectedShowTime].Split('-');
                    int idx = Convert.ToInt32(tmp[0]);
                    comboBox_suatChieu_phim.Text = moviesList[idx].name;
                    comboBox_suatChieu.Text = tmp[2];
                    comboBox_suatChieu_rap.Text = tmp[3];
                }
                else
                {
                    selectedMovie = listView1.SelectedItems[0].Index;
                    pictureBox_thongTin_anh.BackgroundImage = imageListMovies.Images[selectedMovie];
                    textBox_thongTin_tacGia.Text = moviesList[selectedMovie].author;
                    textBox_thongTin_thongTin.Text = moviesList[selectedMovie].infor;
                    textBox_thongTin_phim.Text = moviesList[selectedMovie].name;
                    comboBox_thongTin_trangThai.Text = moviesList[selectedMovie].staus;
                    pictureBox_thongTin_anh.Visible = true;
                }   
            }
            else
            {
                selectedMovie = -1;
            }
        }

        // hàm show trên listview 
        void showListView()
        {
            listView1.Enabled = true;
            checkIsShowTime = false;

            // reset listview 
            listView1.Clear();

            // duyệt qua các phim hiện có 
            for (int i = 0; i < moviesList.Count(); i++)
            {
                listView1.Items.Add(moviesList[i].staus, i);
                imageListMovies.ImageSize = new Size(128, 128);
                listView1.LargeImageList = imageListMovies;
                //int t = imageListMovies.Images.Count;
                listView1.View = View.LargeIcon;
            }
        }

        // tạo hàm chọn ghế
        void chooseSeat(object sender, EventArgs e)
        {
            // tạo button giống với button được chuyền vào
            var button = (Button)sender;
            // lấy số vị trí của button/ghế
            int sltSeat = Convert.ToInt32(button.Name.Replace("button_", "")) - 1;

            // nếu không nằm trong các ghế đã được chọn
            if (lstChooseBtn.Contains(button))
            {
                lstSeats.Remove(sltSeat);
                button.BackColor = Color.Transparent;
                lstChooseBtn.Remove(button);
            }
            else
            {
                button.BackColor = Color.YellowGreen;
                lstSeats.Add(sltSeat); // các ghế đã được chọn
                lstChooseBtn.Add(button);
            }

            lstSeats.Sort();
            foreach(int seat in lstSeats)
            {
                if (seat == lstSeats[0])
                    textBox_soghe.Text = (seat + 1).ToString();
                else
                    textBox_soghe.Text += "," + (seat + 1).ToString();
            }
        }
        

        // tìm ID phim thông qua tên phim
        int findIDFilm(string name)
        {
            for (int i = 0; i < moviesList.Count; i++)
            {
                if(name == moviesList[i].name)
                {
                    return i;
                }
            }
            return -1;
        }

        // show infor to combobox of name film
        void showNameFilm(ComboBox cbb, DateTimePicker day)
        {
            cbb.DataSource = null;
            List<string> nameFilms = new List<string>();

            // duyệt qua tất cả phim
            foreach (movie film in moviesList)
            {
                foreach(showDayTime sd in film.showDays)
                {
                    if(sd.day == dateTimePicker_datve.Value.Day.ToString())
                    {
                        if (nameFilms.Contains(film.name) == false && film.staus == "Đang chiếu")
                            nameFilms.Add(film.name);
                    }
                }
            }

            // đổi data của ccb
            cbb.DataSource = nameFilms;
            cbb.Text = "";
        }

        // hàm show thông tin thời gian hiện có 
        void showTimes(ComboBox cbb,DateTimePicker day)
        {
            
            List<string> times_tmp = new List<string>();
            times_tmp = lstTimes;

            // duyệt qua tất cả các phim
            foreach (movie film in moviesList)
            {
                foreach(showDayTime sd in film.showDays)
                {
                    // duyệt qua tất cả thời gian của phim đang chiếu
                    foreach (showTimeFilm st in sd.showTimes)
                    {
                        // kiểm tra và thêm vào list time được tạo
                        if (st.seats_1 != null && st.seats_2 != null && st.seats_3 != null)
                            times_tmp.Remove(st.time);
                    }
                } 
            }

            // reset combobox về null
            cbb.DataSource = null;

            // thêm data vào cbb
            cbb.DataSource = times_tmp;
            cbb.Text = "";
        }

        // hàm show sơ đồ 
        void showMaps(ComboBox cbbTimes ,ComboBox cbbTheater, DateTimePicker day, bool checkShowMap = false)
        {

            bool checkHasFilm = false;
            movie newFilm = new movie();
            // kiểm tra xem đã điền đủ thông tin chưa 
            if (cbbTimes.Text != "" && cbbTheater.Text != "")
            {
                clearSeats(); // reset hàng ghế lại
                panel_seatsMap.Visible = true; // bật panel

                // duyệt để tìm phim đã chọn
                foreach (movie film in moviesList)
                {
                    foreach(showDayTime sd in film.showDays)
                    {
                        if (sd.day == day.Value.Day.ToString())
                        {
                            // duyệt để tìm sơ đồ và thời gian 
                            foreach (showTimeFilm st in sd.showTimes)
                            {
                                if (st.time == cbbTimes.Text)
                                {
                                    // kiểm tra coi rạp đang chọn là rạp nào 
                                    if (st.seats_1 != null && cbbTheater.Text == "1")
                                    {
                                        checkHasFilm = true;
                                        newFilm = film;
                                        for (int i = 0; i < 37; i++)// 37 ghế ở rạp 1
                                        {
                                            // seats[i] = true , có ghế được book đổi giao điện
                                            if (st.seats_1[i])
                                            {
                                                lstBtn[i].BackColor = Color.Transparent;
                                                lstBtn[i].BackgroundImage = Resources.whitechair;
                                                lstLb[i].BackColor = Color.Red;
                                            }
                                        }
                                    }
                                    else if (st.seats_2 != null && cbbTheater.Text == "2")
                                    {
                                        checkHasFilm = true;
                                        newFilm = film;
                                        for (int i = 0; i < 37; i++)
                                        {
                                            if (st.seats_2[i])
                                            {
                                                lstBtn[i].BackColor = Color.Transparent;
                                                lstBtn[i].BackgroundImage = Resources.whitechair;
                                                lstLb[i].BackColor = Color.Red;
                                            }
                                        }
                                    }
                                    else if (st.seats_3 != null && cbbTheater.Text == "3")
                                    {
                                        checkHasFilm = true;
                                        newFilm = film;
                                        for (int i = 0; i < 37; i++)
                                        {
                                            if (st.seats_3[i])
                                            {
                                                lstBtn[i].BackColor = Color.Transparent;
                                                lstBtn[i].BackgroundImage = Resources.whitechair;
                                                lstLb[i].BackColor = Color.Red;
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
                if (checkHasFilm)
                {
                    showListView();
                    listView1.Enabled = false;

                    label_panel_namePhim.Text = newFilm.name;
                    int idx = findIDFilm(newFilm.name);
                    pictureBox_panel1_avatarFilm.Visible = true;
                    pictureBox_panel1_avatarFilm.BackgroundImage = imageListMovies.Images[idx];
                }
                else
                {
                    label_panel_namePhim.Text = "Chưa có phim";
                    pictureBox_panel1_avatarFilm.Visible = false;
                }

                if (checkShowMap)
                {
                    List<string> tmp = findInfor();
                    dateTimePicker_datve.Text = tmp[0];
                    comboBox_phim.Text = tmp[1];
                    if (tmp[1] != "")
                    {
                        comboBox_rap.Text = comboBox_soDo_rap.Text;
                        comboBox_suat.Text = comboBox_soDo_suat.Text;
                    }
                    else
                    {
                        comboBox_rap.Text = "";
                        comboBox_suat.Text = "";
                    }
                }             
            }
            else
            {
                MessageBox.Show("Hãy điền đầy đủ thông tin tra cứu!!!");
            }
        }

        // hàm reset các ghế về giao diện chuẩn không có ghế nào được book
        void clearSeats()
        {
            for(int i =0; i < 37; i++)
            {
                // kiểm tra có ghế vào được book chưa 
                if(lstLb[i].BackColor == Color.Red || lstBtn[i].BackColor == Color.YellowGreen)
                {
                    lstBtn[i].BackColor = Color.Transparent;
                    lstBtn[i].BackgroundImage = Resources.blackchair;
                    lstLb[i].BackColor = Color.Transparent;
                }
            }
        }

        bool checkIsShowTime = false;
        List<string> showTimesMovies = new List<string>();
        //
        void showListViewShowTime(string day)
        {
            listView1.Enabled = true;
            panel_seatsMap.Visible = false;
            panel_2_addInforFilm.Visible = false;
            int i = 0;

            // reset listview 
            listView1.Clear();

            ImageList imgLstShowTime = new ImageList();
            showTimesMovies.Clear();

            imageListMovies.ImageSize = new Size(128, 128);
            listView1.LargeImageList = imgLstShowTime;
            imgLstShowTime.ImageSize = new Size(128, 128);
            listView1.View = View.LargeIcon;

            for(int idx = 0; idx < moviesList.Count; idx++)
            {
                foreach(showDayTime sd in moviesList[idx].showDays)
                {
                    if(sd.day == day)
                    {
                        Image avatarFilm = imageListMovies.Images[idx];

                        foreach (showTimeFilm st in sd.showTimes)
                        {
                            if (st.seats_1 != null)
                            {
                                if(st.seats_1.Count != 0)
                                {
                                    listView1.Items.Add(st.time + " - rạp 1", i);
                                    listView1.Items[i].BackColor = Color.Red;
                                    listView1.LargeImageList.Images.Add(avatarFilm);
                                    i++;
                                    showTimesMovies.Add(idx + "-" + sd.day + "-" + st.time + "-" + "1");
                                } 
                            }
                            if (st.seats_2 != null)
                            {
                                if(st.seats_2.Count != 0)
                                {
                                    listView1.Items.Add(st.time + " - rạp 2", i);
                                    listView1.Items[i].BackColor = Color.Green;
                                    listView1.LargeImageList.Images.Add(avatarFilm);
                                    i++;
                                    showTimesMovies.Add(idx + "-" + sd.day + "-" + st.time + "-" + "2");
                                }  
                            }
                            if (st.seats_3 != null)
                            {
                                if(st.seats_3.Count != 0)
                                {
                                    listView1.Items.Add(st.time + " - rạp 3", i);
                                    listView1.Items[i].BackColor = Color.Yellow;
                                    listView1.LargeImageList.Images.Add(avatarFilm);
                                    i++;
                                    showTimesMovies.Add(idx + "-" + sd.day + "-" + st.time + "-" + "3");
                                }
                                
                            }

                        }
                    }
                }
            }

            //
            checkIsShowTime = true;
        }

        private void button_phim_cong_Click(object sender, EventArgs e)
        {
            //// kiểm tra có tồn tại đủ thông tin chưa 
            //if(textBox_thongTin_phim.Text != "" && comboBox_thongTin_trangThai.Text != "")
            //{
            //    // lấy đường dẫn ảnh thông qua opendialog
            //    string imagePath = "";
            //    OpenFileDialog chooseImage = new OpenFileDialog();
            //    chooseImage.Title = "Chọn hình đại diện của phim";
            //    chooseImage.InitialDirectory = @"C:/";
            //    chooseImage.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            //    try
            //    {
            //        if (chooseImage.ShowDialog() == DialogResult.OK)
            //        {
            //            imagePath = chooseImage.FileName;
            //        }
            //        else
            //        {
            //            MessageBox.Show("Vui lòng chọn ảnh đại diện cho phim");
            //        }
            //    }
            //    catch
            //    {
            //        MessageBox.Show("Có lỗi xảy ra trong quá trình thực thi!!!");
            //    }
                
            //    // thêm phim vào database
            //    movie newFilm = new movie();
            //    newFilm.name = textBox_thongTin_phim.Text;
            //    newFilm.staus = comboBox_thongTin_trangThai.Text;
            //    newFilm.infor = 
            //    newFilm.showTimes = new List<showTimeFilm>();

            //    // thêm phim vào database 
            //    moviesList.Add(newFilm);
            //    imageListMovies.Images.Add(Image.FromFile(imagePath));

            //    // show phim
            //    showListView();

            //    // setting defaut textbox
            //    //comboBox_tinhtrang.Text = "";
            //    //textBox_danhmuc_phim.Text = "";
            //}
            //else
            //{
            //    MessageBox.Show("Vui lòng nhập đầy đủ thông tin của phim!!!");
            //}
        }
        

        private void comboBox_phim_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if(comboBox_phim.Text != "")
            {
                // lấy giá trị của phim đang được chọn
                int idFilm = findIDFilm(comboBox_phim.Text);
                List<string> times = new List<string>();
                // duyệt thời gian và rạp chiếu 
                foreach(showDayTime sd in moviesList[idFilm].showDays)
                {
                    if(sd.day == dateTimePicker_datve.Value.Day.ToString())
                    {
                        foreach (showTimeFilm st in sd.showTimes)
                        {
                            if (times.Contains(st.time) == false)
                                times.Add(st.time);
                        }
                    }
                }

                comboBox_suat.DataSource = times;
                comboBox_suat.Text = "";

            }
                
        }
        int getNBooked(string day, string time, int theater, bool booked = true)
        {
            int count = 0;
            foreach (movie film in moviesList)
            {
                foreach (showDayTime sd in film.showDays)
                {
                    if (sd.day == day)
                    {
                        foreach (showTimeFilm st in sd.showTimes)
                        {
                            if (st.time == time)
                            {
                                if (theater == 1 && st.seats_1 != null)
                                {
                                    foreach (bool i in st.seats_1)
                                    {
                                        if (i)
                                        {
                                            count++;
                                        }
                                    }
                                }
                                else if (theater == 2 && st.seats_2 != null)
                                {
                                    foreach (bool i in st.seats_2)
                                    {
                                        if (i)
                                        {
                                            count++;
                                        }
                                    }
                                }
                                else if (theater == 3 && st.seats_3 != null)
                                {
                                    foreach (bool i in st.seats_3)
                                    {
                                        if (i)
                                        {
                                            count++;
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                }
            }
            if (booked)
                return count;
            else
                return 37 - count;
        }
        private void button_datve_Click(object sender, EventArgs e)
        {

            if (comboBox_phim.Text != "" && comboBox_suat.Text != "" && comboBox_rap.Text != "")
            {
                if(lstSeats.Count  == 0)
                {
                    MessageBox.Show("Vui lòng chọn ghế");
                }
                else
                {
                    int iDFilm = findIDFilm(comboBox_phim.Text);
                    int theater = Convert.ToInt32(comboBox_rap.Text);
                    if (iDFilm != -1)
                    {
                        foreach(showDayTime sd in moviesList[iDFilm].showDays)
                        {
                            if(sd.day == dateTimePicker_datve.Value.Day.ToString())
                            {
                                // duyệt tìm suất phù hợp với combobox
                                foreach (showTimeFilm st in sd.showTimes)
                                {
                                    if (st.time == comboBox_suat.Text)
                                    {
                                        if (checkFailSeats(theater, true, st))
                                        {
                                            MessageBox.Show("Đã có ghế đã được đặt");
                                            return;
                                        }

                                        // ứng với rạp 1
                                        if (theater == 1)
                                        {
                                            // với mỗi ghế được chọn thì giá trị list seat đó đổi thành true
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_1[seat] = true;
                                            }
                                            //MessageBox.Show("Đặt thành công ghế "+textBox_soghe.Text + " phim "+comboBox_phim.Text+" vào ngày " 
                                                            //+ dateTimePicker_datve.Value + " suất "+comboBox_suat+" rạp "+comboBox_rap.Text);
                                        }
                                        else if (theater == 2)
                                        {
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_2[seat] = true;
                                            }
                                            //MessageBox.Show("Đặt thành công ghế " + textBox_soghe.Text + " phim " + comboBox_phim.Text + " vào ngày "
                                                            //+ dateTimePicker_datve.Value + " suất " + comboBox_suat + " rạp " + comboBox_rap.Text);
                                        }
                                        else if (theater == 3)
                                        {
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_3[seat] = true;
                                            }
                                            //MessageBox.Show("Đặt thành công ghế " + textBox_soghe.Text + " phim " + comboBox_phim.Text + " vào ngày "
                                                           //+ dateTimePicker_datve.Value + " suất " + comboBox_suat.Text + " rạp " + comboBox_rap.Text);
                                        }
                                        break;
                                    }
                                }

                                MessageBox.Show("Đặt thành công ghế " + textBox_soghe.Text + ", Phim " + comboBox_phim.Text + " vào ngày "
                                                           + dateTimePicker_datve.Text + " suất " + comboBox_suat.Text + " rạp " + comboBox_rap.Text + "\n"+"Số tiền bạn cần phải trả là : " + (lstSeats.Count * 45000).ToString() + "đ");

                                // đổi màu ghế và đặt ghế
                                foreach (int s in lstSeats)
                                {
                                    lstBtn[s].BackColor = Color.Transparent;
                                    lstBtn[s].BackgroundImage = Resources.whitechair;
                                    lstLb[s].BackColor = Color.Red;
                                }

                                // reset lstseats được chọn
                                lstSeats.Clear();
                                textBox_soGheChuaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text), false).ToString();
                                textBox_soGheDaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text)).ToString();
                            }
                        }
                        
                    }
                }
            }
            else
            {
                MessageBox.Show("vui lòng nhập đầy đủ thông tin");
            }
        }

        private void comboBox_rap_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearSeats();
            if (comboBox_rap.Text != "" && comboBox_suat.Text != "")
            {
                showMaps(comboBox_suat, comboBox_rap,dateTimePicker_datve);

                textBox_soGheChuaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text), false).ToString();
                textBox_soGheDaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text)).ToString();
            }
        }

        bool checkFailSeats(int theater,bool check , showTimeFilm showTime)
        {
            if(theater == 1)
            {
                foreach (int seat in lstSeats)
                {
                    if (showTime.seats_1[seat] == check)
                        return true;
                }
            }
            else if (theater == 2)
            {
                foreach (int seat in lstSeats)
                {
                    if (showTime.seats_2[seat] == check)
                        return true;
                }
            }
            else if (theater == 3)
            {
                foreach (int seat in lstSeats)
                {
                    if (showTime.seats_3[seat] == check)
                        return true;
                }
            }
            return false;
        }


        private void button_huyve_Click(object sender, EventArgs e)
        {
            if (comboBox_phim.Text != "" && comboBox_suat.Text != "" && comboBox_rap.Text != "")
            {
                if (lstSeats.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn ghế");
                }
                else
                {
                    int iDFilm = findIDFilm(comboBox_phim.Text);
                    int theater = Convert.ToInt32(comboBox_rap.Text);
                    if (iDFilm != -1)
                    {
                        foreach(showDayTime sd in moviesList[iDFilm].showDays)
                        {
                            if(sd.day == dateTimePicker_datve.Value.Day.ToString())
                            {
                                // duyệt tìm suất phù hợp với combobox
                                foreach (showTimeFilm st in sd.showTimes)
                                {
                                    if (st.time == comboBox_suat.Text)
                                    {
                                        if (checkFailSeats(theater, false, st))
                                        {
                                            MessageBox.Show("Đã có ghế chưa được đặt");
                                            return;
                                        }

                                        // ứng với rạp 1
                                        if (theater == 1)
                                        {
                                            // với mỗi ghế được chọn thì giá trị list seat đó đổi thành true
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_1[seat] = false;
                                            }
                                        }
                                        else if (theater == 2)
                                        {
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_2[seat] = false;
                                            }
                                        }
                                        else if (theater == 3)
                                        {
                                            foreach (int seat in lstSeats)
                                            {
                                                st.seats_3[seat] = false;
                                            }
                                        }
                                        break;
                                    }
                                }

                                // đổi màu ghế và đặt ghế
                                foreach (int s in lstSeats)
                                {
                                    lstBtn[s].BackColor = Color.Transparent;
                                    lstBtn[s].BackgroundImage = Resources.blackchair;
                                    lstLb[s].BackColor = Color.Transparent;
                                }

                                // reset lstseats được chọn
                                lstSeats.Clear();
                                textBox_soGheChuaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text), false).ToString();
                                textBox_soGheDaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text)).ToString();
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("vui lòng nhập đầy đủ thông tin");
            }
        }

        private void button_phim_tru_Click(object sender, EventArgs e)
        {
            // kiểm tra có item nào được chọn chưa 
            if (selectedMovie != -1)
            {
                // xóa phim
                moviesList.RemoveAt(selectedMovie);
                imageListMovies.Images.RemoveAt(selectedMovie);
                selectedMovie = -1;
            }

            showListView();
            //textBox_danhmuc_phim.Text = "";
            //comboBox_tinhtrang.Text = "";
        }

        private void groupBox_datve_Enter(object sender, EventArgs e)
        {
            
        }

        private void groupBox_phim_Enter(object sender, EventArgs e)
        {
            showListView();
            panel_seatsMap.Visible = false;
            comboBox_phim.Text = "";
            comboBox_rap.Text = "";
            comboBox_rap.Text = "";
            textBox_soghe.Text = "";
        }

        
        private void BookTickets_Load(object sender, EventArgs e)
        {
            button_datve.FlatAppearance.BorderSize = 0;
            button_huyve.FlatAppearance.BorderSize = 0;

            // tạo list button
            lstBtn= new List<Button> { button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9, button_10, button_11, button_12, button_13, button_14, button_15, button_16, button_17, button_18, button_19, button_20, button_21, button_22, button_23, button_24, button_25, button_26, button_27, button_28, button_29, button_30, button_31, button_32, button_33, button_34, button_35, button_36, button_37 };

            foreach(Button bt in lstBtn)
            {
                bt.FlatAppearance.BorderSize = 0;
            }

            // tạo list label
            lstLb = new List<Label> { label_1, label_2, label_3, label_4, label_5, label_6, label_7, label_8, label_9, label_10, label_11, label_12, label_13, label_14, label_15, label_16, label_17, label_18, label_19, label_20, label_21, label_22, label_23, label_24, label_25, label_26, label_27, label_28, label_29, label_30, label_31, label_32, label_33, label_34, label_35, label_36, label_37 };

            // thêm data vào trước
            createDatabase();
        }

        private void listView1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            getItem();
        }

        private void comboBox_phim_Click(object sender, EventArgs e)
        {
            showNameFilm(comboBox_phim,dateTimePicker_datve);
            showTimes(comboBox_suat,dateTimePicker_datve);
        }

        private void comboBox_danhmuc_phim_Click(object sender, EventArgs e)
        {
            comboBox_suatChieu_phim.DataSource = null;
            List<string> nameFilms = new List<string>();

            // duyệt qua tất cả phim
            foreach (movie film in moviesList)
            {
                if (nameFilms.Contains(film.name) == false && film.staus == "Đang chiếu")
                    nameFilms.Add(film.name);
            }

            // đổi data của ccb
            comboBox_suatChieu_phim.DataSource = nameFilms;
            comboBox_suatChieu_phim.Text = "";
        }

        private void comboBox_danhmuc_phim_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_xemGhe_Click(object sender, EventArgs e)
        {
            showMaps(comboBox_soDo_suat, comboBox_soDo_rap,dateTimePicker_soDo_thoiGian,true);

            textBox_soGheChuaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text), false).ToString();
            textBox_soGheDaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text)).ToString();
            //// bật tắt panel seats_map
            //if(panel_seatsMap.Visible == false)
            //{
            //    panel_seatsMap.Visible = true;
            //}
            //else
            //{
            //    // hủy chọn nếu có chọn ghế
            //    foreach(Button bt in lstBtn)
            //    {
            //        if (bt.BackColor == Color.YellowGreen)
            //            bt.BackColor = Color.Transparent;
            //    }
            //    panel_seatsMap.Visible = false;
            //}
        }

        private void panel_seatsMap_Paint(object sender, PaintEventArgs e)
        {
            if (lstSeats.Count == 0)
                textBox_soghe.Text = "";
        }

        List<string> findInfor()
        {
            List<string> tmp = new List<string>();
            tmp.Add(dateTimePicker_soDo_thoiGian.Text);
            foreach (movie film in moviesList)
            {
                foreach(showDayTime sd in film.showDays)
                {
                    if (sd.day == dateTimePicker_soDo_thoiGian.Value.Day.ToString())
                    {
                        tmp.Add(film.name);
                        return tmp;
                    }
                }
            }
            tmp.Add("");
            return tmp;
        }


        private void button_1_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_2_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void BookTickets_SizeChanged(object sender, EventArgs e)
        {
            if (firstTime)
            {
                defautSize.Width = this.Width;
                defautSize.Height = this.Height;
                firstTime = false;
            }
            else
            {
                this.Width = defautSize.Width;
                this.Height = defautSize.Height;    
            }
        }

        private void textBox_danhmuc_phim_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox_soDo_suat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_soDo_suat_Click(object sender, EventArgs e)
        {
            //comboBox_soDo_suat.DataSource = null;
            //comboBox_soDo_suat.DataSource = lstTimes;
        }

        private void comboBox_soDo_rap_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_soDo_rap_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox_times_Click(object sender, EventArgs e)
        {

        }

        private void comboBox_suat_Click(object sender, EventArgs e)
        {
        }

        private void comboBox_rap_Click(object sender, EventArgs e)
        {
            comboBox_rap.DataSource = null;
            List<int> theaters = new List<int>();

            int idx = findIDFilm(comboBox_phim.Text);
            foreach(showDayTime sd in moviesList[idx].showDays)
            {
                if(sd.day == dateTimePicker_datve.Value.Day.ToString())
                {
                    foreach (showTimeFilm st in sd.showTimes)
                    {
                        if (st.time == comboBox_suat.Text)
                        {
                            if (st.seats_1 != null)
                                if (theaters.Contains(1) == false)
                                    theaters.Add(1);
                            if (st.seats_2 != null)
                                if (theaters.Contains(2) == false)
                                    theaters.Add(2);
                            if (st.seats_3 != null)
                                if (theaters.Contains(3) == false)
                                    theaters.Add(3);
                        }
                    }
                }
            }

            comboBox_rap.DataSource = theaters;
            textBox_soGheChuaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text), false).ToString();
            textBox_soGheDaDat.Text = getNBooked(dateTimePicker_datve.Value.Day.ToString(), comboBox_suat.Text, Convert.ToInt32(comboBox_rap.Text)).ToString();
        }

        private void comboBox_suat_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_rap.Text = "";
            comboBox_rap.DataSource = null;
        }

        private void button_14_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_13_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        void addEmptySeats(int theater, showTimeFilm showTime, List<int> booked = null)
        { 
            if(theater == 1 && showTime.seats_1.Count == 0)
            {
                for(int i = 0;i < 37; i++)
                {
                    if(booked == null)
                    {
                        showTime.seats_1[i] = false;
                    }
                    else
                    {
                        if (booked.Contains(i))
                        {
                            showTime.seats_1[i] = true;
                        }
                        else
                            showTime.seats_1[i] = false;
                    }    
                }
            }
            else if(theater == 2 && showTime.seats_2.Count == 0)
            {
                for (int i = 0; i < 37; i++)
                {
                    if (booked == null)
                    {
                        showTime.seats_2[i] = false;
                    }
                    else
                    {
                        if (booked.Contains(i))
                        {
                            showTime.seats_2[i] = true;
                        }
                        else
                            showTime.seats_2[i] = false;
                    }
                }
            }
            else if (theater == 3 && showTime.seats_3.Count == 0)
            {
                for (int i = 0; i < 37; i++)
                {
                    if (booked == null)
                    {
                        showTime.seats_3[i] = false;
                    }
                    else
                    {
                        if (booked.Contains(i))
                        {
                            showTime.seats_3[i] = true;
                        }
                        else
                            showTime.seats_3[i] = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("thời gian và rạp đã tồn tại");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string newTime = comboBox_suatChieu.Text;
            if (comboBox_suatChieu_phim.Text != "" && newTime != "" && comboBox_suatChieu_rap.Text != "")
            {
                // tìm vị trí của phim trong list
                string day = dateTimePicker_danhMuc_suat.Value.Day.ToString();
                int idx = findIDFilm(comboBox_suatChieu_phim.Text);
                int theater = Convert.ToInt32(comboBox_suatChieu_rap.Text);
                addShowDay(newTime, theater, day, moviesList[idx]);
            }

            showListViewShowTime(dateTimePicker_danhMuc_suat.Value.Day.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(selectedShowTime != -1)
            {
                string[] tmp = showTimesMovies[selectedShowTime].Split('-');
                int idx = Convert.ToInt32(tmp[0]);
                int i = 0;
                foreach (showDayTime sd in moviesList[idx].showDays)
                {
                    if(sd.day == tmp[1])
                    {
                        int j = 0;
                        foreach (showTimeFilm st in sd.showTimes)
                        {
                            if(st.time == tmp[2])
                            {
                                showTimeFilm newTime = new showTimeFilm();
                                newTime.time = st.time;
                                if (tmp[3] == "1")
                                {
                                    newTime.seats_2 = st.seats_2;
                                    newTime.seats_3 = st.seats_3;
                                    
                                }
                                else if(tmp[3] == "2")
                                {
                                    newTime.seats_1 = st.seats_1;
                                    newTime.seats_3 = st.seats_3;
                                }
                                else if(tmp[3] == "3")
                                {
                                    newTime.seats_1 = st.seats_1;
                                    newTime.seats_2 = st.seats_2;
                                }
                                moviesList[idx].showDays[i].showTimes[j] = newTime;
                                showListViewShowTime(dateTimePicker_danhMuc_suat.Value.Day.ToString());
                                return;
                            }
                            j++;
                        }
                    }
                    i++;
                }  
            }
        }

        private void panel_seatsMap_Click(object sender, EventArgs e)
        {
        
            if (lstSeats.Count == 0)
                textBox_soghe.Text = "";
            
        }

        private void groupBox_suatchieu_Enter(object sender, EventArgs e)
        {
            showListViewShowTime(dateTimePicker_danhMuc_suat.Value.Day.ToString());
        }

        private void comboBox_suatChieu_thoiGian_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button_thongTin_themVao_Click(object sender, EventArgs e)
        {
            // kiểm tra có tồn tại đủ thông tin chưa 
            if (textBox_thongTin_phim.Text != "" && comboBox_thongTin_trangThai.Text != "" && textBox_thongTin_tacGia.Text != "" && textBox_thongTin_thongTin.Text != "")
            {
                if(selectedMovie == -1)
                {
                    // lấy đường dẫn ảnh thông qua opendialog
                    string imagePath = "";
                    OpenFileDialog chooseImage = new OpenFileDialog();
                    chooseImage.Title = "Chọn hình đại diện của phim";
                    chooseImage.InitialDirectory = @"C:/";
                    chooseImage.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                    try
                    {
                        if (chooseImage.ShowDialog() == DialogResult.OK)
                        {
                            imagePath = chooseImage.FileName;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Có lỗi xảy ra trong quá trình thực thi!!!");
                    }

                    if (imagePath != "")
                    {
                        // thêm phim vào database
                        movie newFilm = new movie();
                        newFilm.name = textBox_thongTin_phim.Text;
                        newFilm.infor = textBox_thongTin_thongTin.Text;
                        newFilm.author = textBox_thongTin_tacGia.Text;
                        newFilm.staus = comboBox_thongTin_trangThai.Text;
                        newFilm.showDays = new List<showDayTime>();

                        // thêm phim vào database 
                        moviesList.Add(newFilm);
                        imageListMovies.Images.Add(Image.FromFile(imagePath));

                        // show phim
                        showListView();

                        // setting defaut textbox
                        textBox_thongTin_phim.Text = "";
                        textBox_thongTin_thongTin.Text = "";
                        textBox_thongTin_tacGia.Text = "";
                        comboBox_suatChieu.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng chọn ảnh đại diện cho phim");
                    }
                }
                else
                {
                    movie newFilm = new movie();
                    newFilm = moviesList[selectedMovie];
                    newFilm.name = textBox_thongTin_phim.Text;
                    newFilm.author = textBox_thongTin_tacGia.Text;
                    newFilm.staus = comboBox_thongTin_trangThai.Text;
                    newFilm.infor = textBox_thongTin_thongTin.Text;
                    moviesList[selectedMovie] = newFilm;
                }  
            }
            else
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin của phim!!!");
            }
            showListView();
        }

        private void button_thongTin_xoaPhim_Click(object sender, EventArgs e)
        {
            // kiểm tra có item nào được chọn chưa 
            if (selectedMovie != -1)
            {
                // xóa phim
                moviesList.RemoveAt(selectedMovie);
                imageListMovies.Images.RemoveAt(selectedMovie);
                selectedMovie = -1;
            }

            showListView();

            textBox_thongTin_phim.Text = "";
            textBox_thongTin_tacGia.Text = "";
            textBox_thongTin_thongTin.Text = "";
            comboBox_thongTin_trangThai.Text = "";
            pictureBox_thongTin_anh.Visible = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            panel_2_addInforFilm.Visible = false;
        }

        private void button_themPhim_themPhim_Click(object sender, EventArgs e)
        {
            panel_seatsMap.Visible = false;
            panel_2_addInforFilm.Visible = true;

            textBox_thongTin_phim.Text = "";
            textBox_thongTin_tacGia.Text = "";
            textBox_thongTin_thongTin.Text = "";
            comboBox_thongTin_trangThai.Text = "";
            pictureBox_thongTin_anh.Visible = false;

            showListView();
        }

        private void textBox_thongTin_phim_TextChanged(object sender, EventArgs e)
        {
            if(textBox_thongTin_phim.Text == "" && selectedMovie == -1)
            {
                textBox_thongTin_tacGia.Text = "";
                textBox_thongTin_thongTin.Text = "";
                comboBox_thongTin_trangThai.Text = "";
                pictureBox_thongTin_anh.Visible = false;
            }
        }

        private void textBox_thongTin_phim_Click(object sender, EventArgs e)
        {
            if(selectedMovie == -1 && textBox_thongTin_phim.Text == "")
            {
                textBox_thongTin_tacGia.Text = "";
                textBox_thongTin_thongTin.Text = "";
                comboBox_thongTin_trangThai.Text = "";
                pictureBox_thongTin_anh.Visible = false;
            }
        }

        private void dateTimePicker_danhMuc_suat_Enter(object sender, EventArgs e)
        {
            //showListViewShowTime(dateTimePicker_danhMuc_suat.Value.ToString());
        }

        private void dateTimePicker_danhMuc_suat_Move(object sender, EventArgs e)
        {

        }

        private void dateTimePicker_danhMuc_suat_Leave(object sender, EventArgs e)
        {
            //showListViewShowTime(dateTimePicker_danhMuc_suat.Value.ToString())
        }
        
        private void dateTimePicker_danhMuc_suat_ValueChanged_1(object sender, EventArgs e)
        {
            showListViewShowTime(dateTimePicker_danhMuc_suat.Value.Day.ToString());
        }

        private void button_3_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_4_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_5_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_6_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_12_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_11_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_10_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_9_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_15_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_16_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_17_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_18_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_19_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_20_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_21_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_28_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_27_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_26_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_25_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_24_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_23_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_22_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_29_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_30_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_31_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_32_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_33_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_34_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_35_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_36_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }

        private void button_37_Click(object sender, EventArgs e)
        {
            chooseSeat(sender, e);
        }
    }

}
