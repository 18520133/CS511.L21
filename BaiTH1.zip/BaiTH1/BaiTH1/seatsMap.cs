﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using BaiTH1.Properties;
namespace BaiTH1
{
    public partial class seatsMap : Form
    {
        Size defaut_size = new Size();
        bool fisrtTime = true;
        public seatsMap()
        {
            InitializeComponent();
        }


        List<Button> lstBtn = new List<Button>();

        Button addButton(bool check)
        {
            Button btn = new Button();
            //btn.Name = name;
            btn.Text = "";
            btn.Size = new Size(80, 80);
            btn.FlatStyle = FlatStyle.Flat;
            btn.BackColor = Color.Transparent;
            if (check)
            {
                btn.Enabled = false;
            }
            else
            {
                btn.BackgroundImage = Resources.blackchair;
            }
            btn.BackgroundImageLayout = ImageLayout.Stretch;
            btn.FlatAppearance.BorderSize = 0;
            

            return btn;
        }

        private void seatsMap_Load(object sender, EventArgs e)
        {


            lstBtn = new List<Button>() { button1 };
            
            //for(int i = 0; i < 12; i++)
            //{
            //    if(i == 8 || i == 10)
            //    {
            //        flowLayoutPanel1.Controls.Add(addButton(true));
            //    }
            //    else
            //    {
            //        flowLayoutPanel1.Controls.Add(addButton(false));
            //    }
                
            //}

        }

        private void seatsMap_SizeChanged(object sender, EventArgs e)
        {
            if (fisrtTime)
            {
                defaut_size.Width = this.Width;
                defaut_size.Height = this.Height;
                fisrtTime = false;
            }
            this.Width = defaut_size.Width;
            this.Height = defaut_size.Height;
        }

        private void button34_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_manHinh_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {

        }

        private void button22_Click(object sender, EventArgs e)
        {

        }

        private void button23_Click(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {

        }

        private void button26_Click(object sender, EventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {

        }

        private void button28_Click(object sender, EventArgs e)
        {

        }

        private void button29_Click(object sender, EventArgs e)
        {

        }

        private void button30_Click(object sender, EventArgs e)
        {

        }

        private void button31_Click(object sender, EventArgs e)
        {

        }

        private void button32_Click(object sender, EventArgs e)
        {

        }

        private void button33_Click(object sender, EventArgs e)
        {

        }

        private void button35_Click(object sender, EventArgs e)
        {

        }

        private void button36_Click(object sender, EventArgs e)
        {

        }

        private void button37_Click(object sender, EventArgs e)
        {

        }

        private void button38_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        int selectedSeat = -1;
        private void button1_Click_1(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            string btnName = btn.Name;
            int idx = Convert.ToInt32(btn.Name.Replace("button", ""));

            lstBtn[idx - 1].BackgroundImage = Resources.blackchair;
            lstBtn[idx - 1].BackColor = Color.Yellow;
            selectedSeat = idx - 1;
        }
    }
}
