﻿
namespace slide13
{
    partial class Paint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label_penwidth = new System.Windows.Forms.Label();
            this.button_pencolor = new System.Windows.Forms.Button();
            this.radioButton_fillellipse = new System.Windows.Forms.RadioButton();
            this.radioButton_ellipse = new System.Windows.Forms.RadioButton();
            this.radioButton_string = new System.Windows.Forms.RadioButton();
            this.radioButton_fillrectangle = new System.Windows.Forms.RadioButton();
            this.radioButton_retangle = new System.Windows.Forms.RadioButton();
            this.radioButton_line = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_clean = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_loadimg = new System.Windows.Forms.Button();
            this.textBox_y = new System.Windows.Forms.TextBox();
            this.textBox_x = new System.Windows.Forms.TextBox();
            this.label_point = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.label_penwidth);
            this.groupBox1.Controls.Add(this.button_pencolor);
            this.groupBox1.Controls.Add(this.radioButton_fillellipse);
            this.groupBox1.Controls.Add(this.radioButton_ellipse);
            this.groupBox1.Controls.Add(this.radioButton_string);
            this.groupBox1.Controls.Add(this.radioButton_fillrectangle);
            this.groupBox1.Controls.Add(this.radioButton_retangle);
            this.groupBox1.Controls.Add(this.radioButton_line);
            this.groupBox1.Location = new System.Drawing.Point(22, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(332, 225);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Draw";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(158, 194);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 26);
            this.numericUpDown1.TabIndex = 8;
            // 
            // label_penwidth
            // 
            this.label_penwidth.AutoSize = true;
            this.label_penwidth.Location = new System.Drawing.Point(26, 194);
            this.label_penwidth.Name = "label_penwidth";
            this.label_penwidth.Size = new System.Drawing.Size(82, 20);
            this.label_penwidth.TabIndex = 7;
            this.label_penwidth.Text = "Pen Width";
            // 
            // button_pencolor
            // 
            this.button_pencolor.Location = new System.Drawing.Point(72, 151);
            this.button_pencolor.Name = "button_pencolor";
            this.button_pencolor.Size = new System.Drawing.Size(155, 26);
            this.button_pencolor.TabIndex = 6;
            this.button_pencolor.Text = "PenColor";
            this.button_pencolor.UseVisualStyleBackColor = true;
            this.button_pencolor.Click += new System.EventHandler(this.button_pencolor_Click);
            // 
            // radioButton_fillellipse
            // 
            this.radioButton_fillellipse.AutoSize = true;
            this.radioButton_fillellipse.Location = new System.Drawing.Point(175, 116);
            this.radioButton_fillellipse.Name = "radioButton_fillellipse";
            this.radioButton_fillellipse.Size = new System.Drawing.Size(103, 24);
            this.radioButton_fillellipse.TabIndex = 5;
            this.radioButton_fillellipse.TabStop = true;
            this.radioButton_fillellipse.Text = "Fill Ellipse";
            this.radioButton_fillellipse.UseVisualStyleBackColor = true;
            // 
            // radioButton_ellipse
            // 
            this.radioButton_ellipse.AutoSize = true;
            this.radioButton_ellipse.Location = new System.Drawing.Point(175, 72);
            this.radioButton_ellipse.Name = "radioButton_ellipse";
            this.radioButton_ellipse.Size = new System.Drawing.Size(80, 24);
            this.radioButton_ellipse.TabIndex = 4;
            this.radioButton_ellipse.TabStop = true;
            this.radioButton_ellipse.Text = "Ellipse";
            this.radioButton_ellipse.UseVisualStyleBackColor = true;
            // 
            // radioButton_string
            // 
            this.radioButton_string.AutoSize = true;
            this.radioButton_string.Location = new System.Drawing.Point(175, 33);
            this.radioButton_string.Name = "radioButton_string";
            this.radioButton_string.Size = new System.Drawing.Size(76, 24);
            this.radioButton_string.TabIndex = 3;
            this.radioButton_string.TabStop = true;
            this.radioButton_string.Text = "String";
            this.radioButton_string.UseVisualStyleBackColor = true;
            // 
            // radioButton_fillrectangle
            // 
            this.radioButton_fillrectangle.AutoSize = true;
            this.radioButton_fillrectangle.Location = new System.Drawing.Point(20, 116);
            this.radioButton_fillrectangle.Name = "radioButton_fillrectangle";
            this.radioButton_fillrectangle.Size = new System.Drawing.Size(130, 24);
            this.radioButton_fillrectangle.TabIndex = 2;
            this.radioButton_fillrectangle.TabStop = true;
            this.radioButton_fillrectangle.Text = "Fill Rectangle";
            this.radioButton_fillrectangle.UseVisualStyleBackColor = true;
            // 
            // radioButton_retangle
            // 
            this.radioButton_retangle.AutoSize = true;
            this.radioButton_retangle.Location = new System.Drawing.Point(20, 72);
            this.radioButton_retangle.Name = "radioButton_retangle";
            this.radioButton_retangle.Size = new System.Drawing.Size(107, 24);
            this.radioButton_retangle.TabIndex = 1;
            this.radioButton_retangle.TabStop = true;
            this.radioButton_retangle.Text = "Rectangle";
            this.radioButton_retangle.UseVisualStyleBackColor = true;
            // 
            // radioButton_line
            // 
            this.radioButton_line.AutoSize = true;
            this.radioButton_line.Location = new System.Drawing.Point(20, 33);
            this.radioButton_line.Name = "radioButton_line";
            this.radioButton_line.Size = new System.Drawing.Size(64, 24);
            this.radioButton_line.TabIndex = 0;
            this.radioButton_line.TabStop = true;
            this.radioButton_line.Text = "Line";
            this.radioButton_line.UseVisualStyleBackColor = true;
            this.radioButton_line.CheckedChanged += new System.EventHandler(this.radioButton_line_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_clean);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(548, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(369, 488);
            this.panel1.TabIndex = 1;
            // 
            // button_clean
            // 
            this.button_clean.Location = new System.Drawing.Point(94, 252);
            this.button_clean.Name = "button_clean";
            this.button_clean.Size = new System.Drawing.Size(155, 26);
            this.button_clean.TabIndex = 9;
            this.button_clean.Text = "Clean";
            this.button_clean.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_loadimg);
            this.groupBox2.Controls.Add(this.textBox_y);
            this.groupBox2.Controls.Add(this.textBox_x);
            this.groupBox2.Controls.Add(this.label_point);
            this.groupBox2.Location = new System.Drawing.Point(22, 304);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(332, 179);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Image";
            // 
            // button_loadimg
            // 
            this.button_loadimg.Location = new System.Drawing.Point(72, 112);
            this.button_loadimg.Name = "button_loadimg";
            this.button_loadimg.Size = new System.Drawing.Size(155, 26);
            this.button_loadimg.TabIndex = 10;
            this.button_loadimg.Text = "Load Image";
            this.button_loadimg.UseVisualStyleBackColor = true;
            // 
            // textBox_y
            // 
            this.textBox_y.Location = new System.Drawing.Point(207, 35);
            this.textBox_y.Name = "textBox_y";
            this.textBox_y.Size = new System.Drawing.Size(100, 26);
            this.textBox_y.TabIndex = 11;
            // 
            // textBox_x
            // 
            this.textBox_x.Location = new System.Drawing.Point(101, 35);
            this.textBox_x.Name = "textBox_x";
            this.textBox_x.Size = new System.Drawing.Size(100, 26);
            this.textBox_x.TabIndex = 10;
            // 
            // label_point
            // 
            this.label_point.AutoSize = true;
            this.label_point.Location = new System.Drawing.Point(16, 38);
            this.label_point.Name = "label_point";
            this.label_point.Size = new System.Drawing.Size(79, 20);
            this.label_point.TabIndex = 9;
            this.label_point.Text = "Point X, Y";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(15, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(527, 481);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // Paint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 500);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Paint";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Paint_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Paint_MouseDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label_penwidth;
        private System.Windows.Forms.Button button_pencolor;
        private System.Windows.Forms.RadioButton radioButton_fillellipse;
        private System.Windows.Forms.RadioButton radioButton_ellipse;
        private System.Windows.Forms.RadioButton radioButton_string;
        private System.Windows.Forms.RadioButton radioButton_fillrectangle;
        private System.Windows.Forms.RadioButton radioButton_retangle;
        private System.Windows.Forms.RadioButton radioButton_line;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_clean;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_loadimg;
        private System.Windows.Forms.TextBox textBox_y;
        private System.Windows.Forms.TextBox textBox_x;
        private System.Windows.Forms.Label label_point;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

