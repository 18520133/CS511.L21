﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace slide13
{
    public partial class Paint : Form
    {
        public Paint()
        {
            InitializeComponent();
            
        }
        Graphics g;
        Color new_color;
        Pen pen;
        HatchBrush hb;
        Bitmap bm;
        bool moving = false;
        int x, y, sX, sY, cX, cY;

        private void Paint_Load(object sender, EventArgs e)
        {
            bm = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(bm);
            g.Clear(Color.White);
            pictureBox1.Image = bm;

            pen = new Pen(Color.Black, 1);
            hb = new HatchBrush(HatchStyle.Wave, Color.BlueViolet);

            g.SmoothingMode = SmoothingMode.AntiAlias;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            moving = true;
            //px = e.Location;
            cX = e.X;
            cY = e.Y;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            moving = false;
            sX = x - cX;
            sY = y - cY;

            if (radioButton_line.Checked)
                g.DrawLine(pen, cX, cY, x, y);
            if (radioButton_retangle.Checked)
                g.DrawRectangle(pen, cX, cY, sX, sY);
            if (radioButton_fillrectangle.Checked)
                g.FillRectangle(hb, cX, cY, sX, sY);
            if (radioButton_ellipse.Checked == true)
                g.DrawEllipse(hb, cX, cY, sX, sY);
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox1.Refresh();
            x = e.X;
            y = e.Y;
            sX = x - cX;
            sY = y - cY;
        }

        private void button_pencolor_Click(object sender, EventArgs e)
        {
            //colorDialog1.ShowDialog();
            //button_pencolor.BackColor = colorDialog1.Color;
            ColorDialog cdl = new ColorDialog();
            if (cdl.ShowDialog() == DialogResult.OK)
            {
                new_color = cdl.Color;
                pen.Color = new_color;
                button_pencolor.BackColor = new_color;
            }

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Pen p = new Pen(button_pencolor.BackColor);
            //base.OnPaint(e);
            Graphics g = e.Graphics;
            if (radioButton_line.Checked == true)
                g.DrawLine(p, 10,10,40,40);
        }
        private void radioButton_line_CheckedChanged(object sender, EventArgs e)
        {
            
        }
        private void DemoShape(Graphics g)
        {
            
        }

        private void Paint_MouseDown(object sender, MouseEventArgs e)
        {
            
        }
    }
}
