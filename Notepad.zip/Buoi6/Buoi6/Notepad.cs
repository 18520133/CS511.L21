﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Buoi6
{
    public partial class Form_Notepad : Form
    {
        bool save = false;
        public Form_Notepad()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox_notepad.Text != "" && save==false) 
            {
                MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel);
            } 
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            of.Filter = "File Text (*.txt)|*.txt";
            of.FilterIndex = 0;
            of.InitialDirectory= @"C:\Users\Admin\Downloads";
            if (of.ShowDialog() == DialogResult.OK)
            {
                string path = of.FileName;

                string[] text = System.IO.File.ReadAllLines(path);
                string t = String.Join("\n", text);

                textBox_notepad.Text = t;
            }
        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "File Text (*.txt)|*.txt";
            sf.FilterIndex = 0;
            sf.InitialDirectory = @"C:\Users\Admin\Downloads";
            if (sf.ShowDialog() == DialogResult.OK)
            {
                string path = sf.FileName;
                System.IO.File.WriteAllText(path, textBox_notepad.Text);
                this.Text = Path.GetFileName(path);
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                textBox_notepad.SelectionFont = fd.Font;
            }
        }

        private void colorSelectTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog()==DialogResult.OK)
            {
                textBox_notepad.SelectionColor = cd.Color;
            }
        }

        private void colorBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                textBox_notepad.SelectionBackColor = cd.Color;
            }
        }

        private void aboutNotepadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Notication no = new Notication();
            no.Show();
            
            //MessageBox.Show("Notepad", "About Notepad", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void textBox_notepad_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Aloo");
        }

        private void textBox_notepad_MouseHover(object sender, EventArgs e)
        {
            
        }
    }
}
