﻿
namespace Buoi6
{
    partial class Notication
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_abnotepad = new System.Windows.Forms.Label();
            this.pictureBox_noti = new System.Windows.Forms.PictureBox();
            this.button_ok = new System.Windows.Forms.Button();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_noti)).BeginInit();
            this.SuspendLayout();
            // 
            // label_abnotepad
            // 
            this.label_abnotepad.AutoSize = true;
            this.label_abnotepad.BackColor = System.Drawing.Color.White;
            this.label_abnotepad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_abnotepad.Location = new System.Drawing.Point(118, 68);
            this.label_abnotepad.Name = "label_abnotepad";
            this.label_abnotepad.Size = new System.Drawing.Size(174, 58);
            this.label_abnotepad.TabIndex = 5;
            this.label_abnotepad.Text = "About Notepad\r\n\r\n";
            // 
            // pictureBox_noti
            // 
            this.pictureBox_noti.Image = global::Buoi6.Properties.Resources.iconfinder_Internet_Security_guard_lifebuoy_lifesaver_data_information_5172980;
            this.pictureBox_noti.Location = new System.Drawing.Point(28, 53);
            this.pictureBox_noti.Name = "pictureBox_noti";
            this.pictureBox_noti.Size = new System.Drawing.Size(73, 73);
            this.pictureBox_noti.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_noti.TabIndex = 4;
            this.pictureBox_noti.TabStop = false;
            // 
            // button_ok
            // 
            this.button_ok.BackColor = System.Drawing.Color.White;
            this.button_ok.BackgroundImage = global::Buoi6.Properties.Resources.iconfinder_dialog_apply_28337;
            this.button_ok.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_ok.Location = new System.Drawing.Point(155, 142);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(63, 63);
            this.button_ok.TabIndex = 3;
            this.button_ok.UseVisualStyleBackColor = false;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // Notication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label_abnotepad);
            this.Controls.Add(this.pictureBox_noti);
            this.Controls.Add(this.button_ok);
            this.Name = "Notication";
            this.Size = new System.Drawing.Size(371, 225);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_noti)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.PictureBox pictureBox_noti;
        private System.Windows.Forms.Label label_abnotepad;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}
