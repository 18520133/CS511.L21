﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;


namespace slide12
{
    public partial class MDI : Form
    {
        public MDI()
        {
            InitializeComponent();
        }
        
        private void tileHorizonalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }
        private Form activeForm = null;
        private void imageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //OpenFileDialog of = new OpenFileDialog();
            //of.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            //string path = of.FileName;
            //if (of.ShowDialog() == DialogResult.OK)
            //{
            //    SDI_Image fr = new SDI_Image(path);
            //    fr.MdiParent = this;
            //    fr.Show();
            //}
            openFileDialog1.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog1.FileName;
                if (path != "")
                {
                    SDI_Image fr = new SDI_Image(path);
                    fr.MdiParent = this;
                    fr.Show();
                }
            }

        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void notepadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of_np = new OpenFileDialog();
            of_np.Filter = "Text Files(*.txt)|*.txt";
            if (of_np.ShowDialog() == DialogResult.OK)
            {
                string path = of_np.FileName;
                if (path != "")
                {
                    SDI_Notepad fr = new SDI_Notepad(path);
                    fr.MdiParent = this;
                    fr.Show();
                }
            }
        }

        private void wordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of_w = new OpenFileDialog();
            //of_w.Filter = "Doc Files(*.doc; *.docx)|*.doc; *.docx";
            if (of_w.ShowDialog() == DialogResult.OK)
            {
                string path = of_w.FileName;
                if (path != "")
                {
                    SDI_Word fr = new SDI_Word();
                    fr.LoadWord(path);
                    fr.MdiParent = this;
                    fr.Show();
                }
            }
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of_e = new OpenFileDialog();
            if (of_e.ShowDialog() == DialogResult.OK)
            {
                string path = of_e.FileName;
                if (path != "")
                {
                    SDI_Excel fr = new SDI_Excel();
                    fr.LoadExcel(path);
                    fr.MdiParent = this;
                    fr.Show();
                }
            }
        }

        private void pdfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of_pdf = new OpenFileDialog();
            if (of_pdf.ShowDialog() == DialogResult.OK)
            {
                string path = of_pdf.FileName;
                if (path != "")
                {
                    SDI_PDF fr = new SDI_PDF();
                    fr.LoadPDF(path);
                    fr.Show();
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
