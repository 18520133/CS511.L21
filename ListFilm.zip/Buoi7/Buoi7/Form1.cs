﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buoi7
{
    public partial class Form_wpl : Form
    {
        public Form_wpl()
        {
            InitializeComponent();
        }
        int ItemsIndex;
        void addfilm(string IDfilm)
        {
            listView1.Items.Add(IDfilm,0);
            listView1.LargeImageList = imageList1;
            listView1.View = View.LargeIcon;
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog_open.Filter = "Video,Music Files(*.MP3; *.MP4; *.WMV; *.GIF)| *.MP3; *.MP4; *.WMV; *.GIF";

            if (openFileDialog_open.ShowDialog() == DialogResult.OK)

            {
                axWindowsMediaPlayer1.URL = openFileDialog_open.FileName;
                addfilm(openFileDialog_open.FileName);
                //listView1.Items[ItemsIndex].BackColor = Color.Red;
            }
        }
        private string[] files, path;

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            ItemsIndex = e.ItemIndex;
            files = openFileDialog_add.SafeFileNames;
            path = openFileDialog_add.FileNames;
            axWindowsMediaPlayer1.URL = path[0];
            int i = 0;
            while (i<files.Length)
            {
                listView1.Items[i].BackColor = Color.Transparent;
            }
            listView1.Items[ItemsIndex].BackColor = Color.Red;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This app is created by Nguyen Duong Truc Phuong", "About",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void addMediaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            openFileDialog_add.Filter = "Video,Music Files(*.MP3; *.MP4; *.WMV; *.GIF)| *.MP3; *.MP4; *.WMV; *.GIF";

            if (openFileDialog_add.ShowDialog() == System.Windows.Forms.DialogResult.OK)

            {
                listView1.Items.Clear();

                files = openFileDialog_add.SafeFileNames;

                path = openFileDialog_add.FileNames;

                for (int i = 0; i < files.Length; i++)

                {
                    addfilm(files[i]);
                }
                
                axWindowsMediaPlayer1.URL = path[0];
                for (int i = 0; i < files.Length; i++)

                {
                    if (listView1.Items[ItemsIndex].Checked == true)
                    {
                        axWindowsMediaPlayer1.URL = path[i];
                    }
                }
                
                
                //listView1.SelectedIndex++;

            }

        }
    }
}
