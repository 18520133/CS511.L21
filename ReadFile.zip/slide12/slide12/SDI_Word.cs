﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slide12
{
    public partial class SDI_Word : Form
    {
        public SDI_Word()
        {
            InitializeComponent();
        }
        public void LoadWord(string f)
        {
            try
            {
                object readOnly = true;
                object visible = true;
                object save = false;
                object fileName = f;
                object missing = Type.Missing;
                object newTemplate = false;
                object docType = 0;
                Microsoft.Office.Interop.Word._Document oDoc = null;
                Microsoft.Office.Interop.Word._Application oWord = new Microsoft.Office.Interop.Word.Application() { Visible = false };
                oDoc = oWord.Documents.Open(
                ref fileName, ref missing, ref readOnly, ref missing,
                ref missing, ref missing, ref missing, ref missing,
                ref missing, ref missing, ref missing, ref visible,
                ref missing, ref missing, ref missing, ref missing);
                oDoc.ActiveWindow.Selection.WholeStory();
                oDoc.ActiveWindow.Selection.Copy();
                IDataObject data = Clipboard.GetDataObject();
                richTextBox1.Rtf = data.GetData(DataFormats.Rtf).ToString();
                oWord.Quit(ref missing, ref missing, ref missing);
            }
            catch { }
        }
        private void SDI_Word_Load(object sender, EventArgs e)
        {

        }
    }
}
