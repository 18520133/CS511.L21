﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace slide12
{
    public partial class SDI_Excel : Form
    {
        public SDI_Excel()
        {
            InitializeComponent();
        }
        public void LoadExcel(string Path_fileName)
        {
            DataTable dt = new DataTable();
            Excel.Application excelApp = new Excel.Application();
            if (excelApp != null)
            {
                Excel.Workbook excelWorkbook = excelApp.Workbooks.Open(Path_fileName, 0, true, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                Excel.Worksheet excelWorksheet = (Excel.Worksheet)excelWorkbook.Sheets[1];



                Excel.Range excelRange = excelWorksheet.UsedRange;
                int rowCount = excelRange.Rows.Count;
                int colCount = excelRange.Columns.Count;



                //Dòng 1 (đầu tiên) trong file excel là tên cột
                for (int j = 1; j <= colCount; j++)
                {
                    Excel.Range range = (excelWorksheet.Cells[1, j] as Excel.Range);
                    dt.Columns.Add(range.Value.ToString());
                }
                //Đọc dữ liệu từ dòng 2
                for (int i = 2; i <= rowCount; i++)
                {
                    string[] value = new string[colCount];
                    for (int j = 1; j <= colCount; j++)
                    {
                        Excel.Range range = (excelWorksheet.Cells[i, j] as Excel.Range);
                        string cellValue = "";
                        try
                        {
                            cellValue = range.Value.ToString();
                        }
                        catch { }
                        value[j - 1] = cellValue;
                    }
                    dt.Rows.Add(value);
                }



                excelWorkbook.Close();
                excelApp.Quit();



                dataGridView1.DataSource = dt;
            }
        }
        private void SDI_Excel_Load(object sender, EventArgs e)
        {

        }
    }
}
