﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slide12
{
    public partial class SDI_PDF : Form
    {
        public SDI_PDF()
        {
            InitializeComponent();
        }
        public void LoadPDF(string f)
        {
            axAcroPDF1.LoadFile(f);
        }
        private void SDI_PDF_Load(object sender, EventArgs e)
        {

        }
    }
}
