﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace slide12
{
    public partial class SDI_Notepad : Form
    {
        public SDI_Notepad()
        {
            InitializeComponent();
        }
        public SDI_Notepad(string f)
        {
            InitializeComponent();
            richTextBox1.Text = File.ReadAllText(f);
        }
        private void SDI_Notepad_Load(object sender, EventArgs e)
        {

        }
    }
}
