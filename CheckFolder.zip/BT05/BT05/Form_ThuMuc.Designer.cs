﻿
namespace BT05
{
    partial class Form_ThuMuc
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_thuMuc = new System.Windows.Forms.GroupBox();
            this.button_xoaThuMuc = new System.Windows.Forms.Button();
            this.button_xoaAllfile = new System.Windows.Forms.Button();
            this.button_taoThuMuc = new System.Windows.Forms.Button();
            this.button_ktThuMuc = new System.Windows.Forms.Button();
            this.textBox_tenThuMuc = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_tenThuMuc = new System.Windows.Forms.Label();
            this.label_oCung = new System.Windows.Forms.Label();
            this.groupBox_ZIP = new System.Windows.Forms.GroupBox();
            this.button_giaiNenFile = new System.Windows.Forms.Button();
            this.button_nenFile = new System.Windows.Forms.Button();
            this.textBox_thuMucGiaiNen = new System.Windows.Forms.TextBox();
            this.label_thuMucGiaiNen = new System.Windows.Forms.Label();
            this.textBox_fileNen_giai = new System.Windows.Forms.TextBox();
            this.label_fileNen_giai = new System.Windows.Forms.Label();
            this.textBox_thuMucNen = new System.Windows.Forms.TextBox();
            this.textBox_fileNen_nen = new System.Windows.Forms.TextBox();
            this.label_fileNen_nen = new System.Windows.Forms.Label();
            this.label_thuMucNen = new System.Windows.Forms.Label();
            this.label_thongBao = new System.Windows.Forms.Label();
            this.textBox_thongBao = new System.Windows.Forms.TextBox();
            this.groupBox_thuMuc.SuspendLayout();
            this.groupBox_ZIP.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_thuMuc
            // 
            this.groupBox_thuMuc.BackColor = System.Drawing.Color.LightSkyBlue;
            this.groupBox_thuMuc.Controls.Add(this.button_xoaThuMuc);
            this.groupBox_thuMuc.Controls.Add(this.button_xoaAllfile);
            this.groupBox_thuMuc.Controls.Add(this.button_taoThuMuc);
            this.groupBox_thuMuc.Controls.Add(this.button_ktThuMuc);
            this.groupBox_thuMuc.Controls.Add(this.textBox_tenThuMuc);
            this.groupBox_thuMuc.Controls.Add(this.comboBox1);
            this.groupBox_thuMuc.Controls.Add(this.label_tenThuMuc);
            this.groupBox_thuMuc.Controls.Add(this.label_oCung);
            this.groupBox_thuMuc.Location = new System.Drawing.Point(15, 14);
            this.groupBox_thuMuc.Name = "groupBox_thuMuc";
            this.groupBox_thuMuc.Size = new System.Drawing.Size(597, 198);
            this.groupBox_thuMuc.TabIndex = 0;
            this.groupBox_thuMuc.TabStop = false;
            this.groupBox_thuMuc.Text = "THƯ MỤC";
            // 
            // button_xoaThuMuc
            // 
            this.button_xoaThuMuc.Location = new System.Drawing.Point(460, 137);
            this.button_xoaThuMuc.Name = "button_xoaThuMuc";
            this.button_xoaThuMuc.Size = new System.Drawing.Size(130, 34);
            this.button_xoaThuMuc.TabIndex = 8;
            this.button_xoaThuMuc.Text = "Xóa Thư Mục";
            this.button_xoaThuMuc.UseVisualStyleBackColor = true;
            this.button_xoaThuMuc.Click += new System.EventHandler(this.button_xoaThuMuc_Click);
            // 
            // button_xoaAllfile
            // 
            this.button_xoaAllfile.Location = new System.Drawing.Point(320, 137);
            this.button_xoaAllfile.Name = "button_xoaAllfile";
            this.button_xoaAllfile.Size = new System.Drawing.Size(134, 34);
            this.button_xoaAllfile.TabIndex = 7;
            this.button_xoaAllfile.Text = "Xóa tất cả file ";
            this.button_xoaAllfile.UseVisualStyleBackColor = true;
            this.button_xoaAllfile.Click += new System.EventHandler(this.button_xoaAllfile_Click);
            // 
            // button_taoThuMuc
            // 
            this.button_taoThuMuc.Location = new System.Drawing.Point(181, 137);
            this.button_taoThuMuc.Name = "button_taoThuMuc";
            this.button_taoThuMuc.Size = new System.Drawing.Size(133, 34);
            this.button_taoThuMuc.TabIndex = 6;
            this.button_taoThuMuc.Text = "Tạo thư mục";
            this.button_taoThuMuc.UseVisualStyleBackColor = true;
            this.button_taoThuMuc.Click += new System.EventHandler(this.button_taoThuMuc_Click);
            // 
            // button_ktThuMuc
            // 
            this.button_ktThuMuc.Location = new System.Drawing.Point(9, 137);
            this.button_ktThuMuc.Name = "button_ktThuMuc";
            this.button_ktThuMuc.Size = new System.Drawing.Size(166, 34);
            this.button_ktThuMuc.TabIndex = 5;
            this.button_ktThuMuc.Text = "Kiểm tra thư mục";
            this.button_ktThuMuc.UseVisualStyleBackColor = true;
            this.button_ktThuMuc.Click += new System.EventHandler(this.button_ktThuMuc_Click);
            // 
            // textBox_tenThuMuc
            // 
            this.textBox_tenThuMuc.Location = new System.Drawing.Point(173, 83);
            this.textBox_tenThuMuc.Name = "textBox_tenThuMuc";
            this.textBox_tenThuMuc.Size = new System.Drawing.Size(200, 31);
            this.textBox_tenThuMuc.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "C:\\"});
            this.comboBox1.Location = new System.Drawing.Point(173, 33);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(201, 33);
            this.comboBox1.TabIndex = 2;
            // 
            // label_tenThuMuc
            // 
            this.label_tenThuMuc.AutoSize = true;
            this.label_tenThuMuc.Location = new System.Drawing.Point(24, 80);
            this.label_tenThuMuc.Name = "label_tenThuMuc";
            this.label_tenThuMuc.Size = new System.Drawing.Size(109, 25);
            this.label_tenThuMuc.TabIndex = 1;
            this.label_tenThuMuc.Text = "Tên thư mục";
            // 
            // label_oCung
            // 
            this.label_oCung.AutoSize = true;
            this.label_oCung.Location = new System.Drawing.Point(24, 38);
            this.label_oCung.Name = "label_oCung";
            this.label_oCung.Size = new System.Drawing.Size(71, 25);
            this.label_oCung.TabIndex = 0;
            this.label_oCung.Text = "Ổ cứng";
            // 
            // groupBox_ZIP
            // 
            this.groupBox_ZIP.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.groupBox_ZIP.Controls.Add(this.button_giaiNenFile);
            this.groupBox_ZIP.Controls.Add(this.button_nenFile);
            this.groupBox_ZIP.Controls.Add(this.textBox_thuMucGiaiNen);
            this.groupBox_ZIP.Controls.Add(this.label_thuMucGiaiNen);
            this.groupBox_ZIP.Controls.Add(this.textBox_fileNen_giai);
            this.groupBox_ZIP.Controls.Add(this.label_fileNen_giai);
            this.groupBox_ZIP.Controls.Add(this.textBox_thuMucNen);
            this.groupBox_ZIP.Controls.Add(this.textBox_fileNen_nen);
            this.groupBox_ZIP.Controls.Add(this.label_fileNen_nen);
            this.groupBox_ZIP.Controls.Add(this.label_thuMucNen);
            this.groupBox_ZIP.Location = new System.Drawing.Point(15, 218);
            this.groupBox_ZIP.Name = "groupBox_ZIP";
            this.groupBox_ZIP.Size = new System.Drawing.Size(597, 185);
            this.groupBox_ZIP.TabIndex = 4;
            this.groupBox_ZIP.TabStop = false;
            this.groupBox_ZIP.Text = "ZIP";
            // 
            // button_giaiNenFile
            // 
            this.button_giaiNenFile.Location = new System.Drawing.Point(321, 129);
            this.button_giaiNenFile.Name = "button_giaiNenFile";
            this.button_giaiNenFile.Size = new System.Drawing.Size(133, 34);
            this.button_giaiNenFile.TabIndex = 10;
            this.button_giaiNenFile.Text = "Giải nén file";
            this.button_giaiNenFile.UseVisualStyleBackColor = true;
            // 
            // button_nenFile
            // 
            this.button_nenFile.Location = new System.Drawing.Point(109, 129);
            this.button_nenFile.Name = "button_nenFile";
            this.button_nenFile.Size = new System.Drawing.Size(133, 34);
            this.button_nenFile.TabIndex = 9;
            this.button_nenFile.Text = "Nén file";
            this.button_nenFile.UseVisualStyleBackColor = true;
            this.button_nenFile.Click += new System.EventHandler(this.button_nenFile_Click);
            // 
            // textBox_thuMucGiaiNen
            // 
            this.textBox_thuMucGiaiNen.Location = new System.Drawing.Point(398, 82);
            this.textBox_thuMucGiaiNen.Name = "textBox_thuMucGiaiNen";
            this.textBox_thuMucGiaiNen.Size = new System.Drawing.Size(102, 31);
            this.textBox_thuMucGiaiNen.TabIndex = 8;
            // 
            // label_thuMucGiaiNen
            // 
            this.label_thuMucGiaiNen.AutoSize = true;
            this.label_thuMucGiaiNen.Location = new System.Drawing.Point(244, 85);
            this.label_thuMucGiaiNen.Name = "label_thuMucGiaiNen";
            this.label_thuMucGiaiNen.Size = new System.Drawing.Size(148, 25);
            this.label_thuMucGiaiNen.TabIndex = 7;
            this.label_thuMucGiaiNen.Text = "Thư mục giải nén";
            // 
            // textBox_fileNen_giai
            // 
            this.textBox_fileNen_giai.Location = new System.Drawing.Point(398, 37);
            this.textBox_fileNen_giai.Name = "textBox_fileNen_giai";
            this.textBox_fileNen_giai.Size = new System.Drawing.Size(102, 31);
            this.textBox_fileNen_giai.TabIndex = 6;
            // 
            // label_fileNen_giai
            // 
            this.label_fileNen_giai.AutoSize = true;
            this.label_fileNen_giai.Location = new System.Drawing.Point(288, 37);
            this.label_fileNen_giai.Name = "label_fileNen_giai";
            this.label_fileNen_giai.Size = new System.Drawing.Size(105, 25);
            this.label_fileNen_giai.TabIndex = 5;
            this.label_fileNen_giai.Text = "File giải nén";
            // 
            // textBox_thuMucNen
            // 
            this.textBox_thuMucNen.Location = new System.Drawing.Point(127, 37);
            this.textBox_thuMucNen.Name = "textBox_thuMucNen";
            this.textBox_thuMucNen.Size = new System.Drawing.Size(102, 31);
            this.textBox_thuMucNen.TabIndex = 4;
            this.textBox_thuMucNen.Text = "C:\\";
            // 
            // textBox_fileNen_nen
            // 
            this.textBox_fileNen_nen.Location = new System.Drawing.Point(127, 82);
            this.textBox_fileNen_nen.Name = "textBox_fileNen_nen";
            this.textBox_fileNen_nen.Size = new System.Drawing.Size(102, 31);
            this.textBox_fileNen_nen.TabIndex = 3;
            // 
            // label_fileNen_nen
            // 
            this.label_fileNen_nen.AutoSize = true;
            this.label_fileNen_nen.Location = new System.Drawing.Point(6, 79);
            this.label_fileNen_nen.Name = "label_fileNen_nen";
            this.label_fileNen_nen.Size = new System.Drawing.Size(72, 25);
            this.label_fileNen_nen.TabIndex = 1;
            this.label_fileNen_nen.Text = "File nén";
            // 
            // label_thuMucNen
            // 
            this.label_thuMucNen.AutoSize = true;
            this.label_thuMucNen.Location = new System.Drawing.Point(6, 37);
            this.label_thuMucNen.Name = "label_thuMucNen";
            this.label_thuMucNen.Size = new System.Drawing.Size(115, 25);
            this.label_thuMucNen.TabIndex = 0;
            this.label_thuMucNen.Text = "Thư mục nén";
            // 
            // label_thongBao
            // 
            this.label_thongBao.AutoSize = true;
            this.label_thongBao.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_thongBao.ForeColor = System.Drawing.Color.Red;
            this.label_thongBao.Location = new System.Drawing.Point(634, 31);
            this.label_thongBao.Name = "label_thongBao";
            this.label_thongBao.Size = new System.Drawing.Size(122, 25);
            this.label_thongBao.TabIndex = 5;
            this.label_thongBao.Text = "THÔNG BÁO";
            // 
            // textBox_thongBao
            // 
            this.textBox_thongBao.Location = new System.Drawing.Point(632, 75);
            this.textBox_thongBao.Multiline = true;
            this.textBox_thongBao.Name = "textBox_thongBao";
            this.textBox_thongBao.Size = new System.Drawing.Size(419, 327);
            this.textBox_thongBao.TabIndex = 6;
            // 
            // Form_ThuMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 417);
            this.Controls.Add(this.textBox_thongBao);
            this.Controls.Add(this.label_thongBao);
            this.Controls.Add(this.groupBox_ZIP);
            this.Controls.Add(this.groupBox_thuMuc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form_ThuMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thư mục";
            this.groupBox_thuMuc.ResumeLayout(false);
            this.groupBox_thuMuc.PerformLayout();
            this.groupBox_ZIP.ResumeLayout(false);
            this.groupBox_ZIP.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_thuMuc;
        private System.Windows.Forms.TextBox textBox_tenThuMuc;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label_tenThuMuc;
        private System.Windows.Forms.Label label_oCung;
        private System.Windows.Forms.GroupBox groupBox_ZIP;
        private System.Windows.Forms.TextBox textBox_fileNen_nen;
        private System.Windows.Forms.Label label_fileNen_nen;
        private System.Windows.Forms.Label label_thuMucNen;
        private System.Windows.Forms.Label label_fileNen_giai;
        private System.Windows.Forms.TextBox textBox_thuMucNen;
        private System.Windows.Forms.TextBox textBox_thuMucGiaiNen;
        private System.Windows.Forms.Label label_thuMucGiaiNen;
        private System.Windows.Forms.TextBox textBox_fileNen_giai;
        private System.Windows.Forms.Button button_xoaThuMuc;
        private System.Windows.Forms.Button button_xoaAllfile;
        private System.Windows.Forms.Button button_taoThuMuc;
        private System.Windows.Forms.Button button_ktThuMuc;
        private System.Windows.Forms.Button button_giaiNenFile;
        private System.Windows.Forms.Button button_nenFile;
        private System.Windows.Forms.Label label_thongBao;
        private System.Windows.Forms.TextBox textBox_thongBao;
    }
}

