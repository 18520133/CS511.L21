﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BT05
{
    public partial class Form_ThuMuc : Form
    {
        public Form_ThuMuc()
        {
            InitializeComponent();
        }

        private void button_taoThuMuc_Click(object sender, EventArgs e)
        {
            string directorypath = @"C:\Users\Admin\Downloads\"+textBox_tenThuMuc.Text;
            DirectoryInfo directory = new DirectoryInfo(directorypath);
            if (!directory.Exists)
            {
                directory.Create();
                Console.WriteLine("Thu muc {0} da duoc tao.", directory.Name);
                textBox_thongBao.Text = "Tạo thư mục thành công!";
            }
            else
            {
                Console.WriteLine("Thu muc {0} da ton tai.", directory.Name);
                textBox_thongBao.Text = "Tạo thư mục không thành công vì thư mục đã tồn tại!";
            }
            Console.ReadLine();
        }

        private void button_ktThuMuc_Click(object sender, EventArgs e)
        {
            string directorypath = @"C:\Users\Admin\Downloads\"+textBox_tenThuMuc.Text;
            
            if (Directory.Exists(directorypath))
                textBox_thongBao.Text = "Thư mục "+textBox_tenThuMuc.Text+" có tồn tại file!";
            else
                textBox_thongBao.Text = "Thư mục "+textBox_tenThuMuc.Text+" rỗng!";
            
        }

        private void button_xoaThuMuc_Click(object sender, EventArgs e)
        {
            string directorypath = @"C:\Users\Admin\Downloads\" + textBox_tenThuMuc.Text;
            DirectoryInfo directory = new DirectoryInfo(directorypath);
                if (directory.Exists)
                {
                    directory.Delete();
                    Console.WriteLine("Thu muc {0} da duoc xoa.", directory.Name);
                    textBox_thongBao.Text = "Xóa thư mục "+textBox_tenThuMuc.Text+" thành công!";
                }
                else
                {
                    Console.WriteLine("Thu muc {0} khong ton tai.", directory.Name);
                    textBox_thongBao.Text = "Xóa thư mục không thành công vì thư mục "+ textBox_tenThuMuc.Text + " không tồn tại!";
                }
            Console.ReadLine();
        }

        private void button_xoaAllfile_Click(object sender, EventArgs e)
        {
            string directorypath = @"C:\Users\Admin\Downloads\" + textBox_tenThuMuc.Text;
            DirectoryInfo directory = new DirectoryInfo(directorypath);
            if (directory.Exists)
            {
                foreach (FileInfo file in directory.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in directory.GetDirectories())
                {
                    dir.Delete(true);
                }
                textBox_thongBao.Text = "Xóa tất cả file trong thư mục " + textBox_tenThuMuc.Text + " thành công!";
            }
            else
                textBox_thongBao.Text = "Xóa tất cả file không thành công vì thư mục " + textBox_tenThuMuc.Text + " không tồn tại file!";
        }

        private void button_nenFile_Click(object sender, EventArgs e)
        {
            //string inputDir = @"C:\Users\Admin\Downloads\";
            //string zipPath = @"C:\Users\Admin\Downloads\"+textBox_fileNen_nen.Text;
            //string extractPath = @"C:\Users\Admin\Downloads\";
            //ZipFile.CreateFromDirectory(inputDir, zipPath);
            //ZipFile.ExtractToDirectory(zipPath, extractPath);
            //textBox_thongBao.Text = "Nén file " + textBox_fileNen_nen + " thành công!";
        }
    }
}
